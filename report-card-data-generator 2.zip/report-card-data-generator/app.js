const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
const cors = require('cors');
const OpenAI = require('openai');
require('dotenv').config();

const app = express();
const PORT = 1443;

// Initialize OpenAI
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

app.use(cors());
app.use(express.json());

// AI analysis cache: keyed by "student|subject", value = { data, timestamp }
const aiCache = new Map();
const AI_CACHE_TTL = 30 * 60 * 1000; // 30 minutes

function getCachedAI(student, subject) {
    const key = `${student}|${subject}`;
    const entry = aiCache.get(key);
    if (entry && (Date.now() - entry.timestamp) < AI_CACHE_TTL) {
        return entry.data;
    }
    if (entry) aiCache.delete(key);
    return null;
}

function setCachedAI(student, subject, data) {
    aiCache.set(`${student}|${subject}`, { data, timestamp: Date.now() });
}

// Serve static files - specific routes first before general
app.use('/assets', express.static(path.join(__dirname, 'assets')));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
// Serve root directory files (index.html, etc)
app.use(express.static(__dirname));

// Path to the CSV file
const CSV_PATH = path.join(__dirname, '..', 'teacher-report-generator', 'reports.csv');

// Academic Enabler JSON helpers
const AE_PATH = path.join(__dirname, 'academic-enabler.json');

function readAE() {
    try {
        if (!fs.existsSync(AE_PATH)) {
            fs.writeFileSync(AE_PATH, '[]', 'utf8');
            return [];
        }
        return JSON.parse(fs.readFileSync(AE_PATH, 'utf8'));
    } catch (e) {
        return [];
    }
}

function writeAE(data) {
    fs.writeFileSync(AE_PATH, JSON.stringify(data, null, 2), 'utf8');
}

// Function to read and parse CSV
function readCSV() {
    return new Promise((resolve, reject) => {
        const results = [];
        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (data) => {
                // Parse Skills JSON if it exists
                if (data.Skills) {
                    try {
                        data.Skills = JSON.parse(data.Skills);
                    } catch (e) {
                        data.Skills = {};
                    }
                }

                // Parse Scores JSON if it exists
                if (data.Scores) {
                    try {
                        data.Scores = JSON.parse(data.Scores);
                    } catch (e) {
                        data.Scores = {};
                    }
                }

                results.push(data);
            })
            .on('end', () => resolve(results))
            .on('error', (error) => reject(error));
    });
}

// Get unique students
app.get('/api/students', async (req, res) => {
    try {
        const reports = await readCSV();
        const students = [...new Set(reports.map(r => r['Student Name']))].filter(Boolean).sort();
        res.json(students);
    } catch (error) {
        console.error('Error reading students:', error);
        res.status(500).json({ error: 'Failed to read student data' });
    }
});

// Get unique teachers (optionally filtered by student)
app.get('/api/teachers', async (req, res) => {
    try {
        const reports = await readCSV();
        const { student } = req.query;
        const filtered = student
            ? reports.filter(r => r['Student Name'] === student)
            : reports;
        const raw = [...new Set(filtered.map(r => r['Teacher Name']).filter(Boolean))];
        const teachers = raw.map(t => {
            const match = t.match(/\[([^\]]+)\]\s*(.*)/);
            return match
                ? { nickname: match[1], fullName: match[2].trim(), raw: t }
                : { nickname: '', fullName: t.trim(), raw: t };
        });
        teachers.sort((a, b) => a.fullName.localeCompare(b.fullName));
        res.json(teachers);
    } catch (error) {
        console.error('Error reading teachers:', error);
        res.status(500).json({ error: 'Failed to read teacher data' });
    }
});

// Get unique subjects (optionally filtered by student)
app.get('/api/subjects', async (req, res) => {
    try {
        const reports = await readCSV();
        const { student } = req.query;

        let filtered = reports;
        if (student) {
            filtered = reports.filter(r => r['Student Name'] === student);
        }

        const subjects = [...new Set(filtered.map(r => r.Subject))].filter(Boolean).sort();
        res.json(subjects);
    } catch (error) {
        console.error('Error reading subjects:', error);
        res.status(500).json({ error: 'Failed to read subject data' });
    }
});

// Get all reports (optionally filtered by student)
app.get('/api/reports', async (req, res) => {
    try {
        const reports = await readCSV();
        const { student } = req.query;

        if (student) {
            const filtered = reports.filter(r => r['Student Name'] === student);
            res.json(filtered);
        } else {
            res.json(reports);
        }
    } catch (error) {
        console.error('Error reading reports:', error);
        res.status(500).json({ error: 'Failed to read reports' });
    }
});

// Get filtered report card data
app.get('/api/report-card-data', async (req, res) => {
    try {
        const { student, subject } = req.query;

        if (!student || !subject) {
            return res.status(400).json({ error: 'Student and subject are required' });
        }

        const reports = await readCSV();

        // Filter by student and subject
        const filteredReports = reports.filter(r =>
            r['Student Name'] === student && r.Subject === subject
        );

        // Sort by date (oldest first)
        filteredReports.sort((a, b) => new Date(a.Date) - new Date(b.Date));

        // Format the data for table display
        const tableData = filteredReports.map(report => {
            const scores = report.Scores || {};

            // Helper function to handle empty strings and missing values
            const getValue = (value) => {
                if (value === null || value === undefined || value === '') {
                    return '';
                }
                return value;
            };

            // Extract name from brackets [Name] format
            let teacherName = report['Teacher Name'] || '-';
            if (teacherName !== '-') {
                const match = teacherName.match(/\[([^\]]+)\]/);
                if (match) {
                    teacherName = match[1];
                }
            }

            return {
                date: report.Date || '-',
                bookMaterialsScore: getValue(scores.bookMaterials?.score),
                bookMaterialsTotal: getValue(scores.bookMaterials?.total),
                vocabularyScore: getValue(scores.vocabulary?.score),
                vocabularyTotal: getValue(scores.vocabulary?.total),
                classVideoScore: getValue(scores.classVideo?.score),
                classVideoTotal: getValue(scores.classVideo?.total),
                homeworkScore: getValue(scores.homework?.score),
                homeworkTotal: getValue(scores.homework?.total),
                homeworkVocabScore: getValue(scores.homeworkVocab?.score),
                homeworkVocabTotal: getValue(scores.homeworkVocab?.total),
                weeklyTestScore: getValue(scores.weeklyTest?.score),
                weeklyTestTotal: getValue(scores.weeklyTest?.total),
                teacherName: teacherName
            };
        });

        res.json({
            student,
            subject,
            count: tableData.length,
            data: tableData
        });
    } catch (error) {
        console.error('Error generating report card data:', error);
        res.status(500).json({ error: 'Failed to generate report card data' });
    }
});

// AI Analysis endpoint
app.get('/api/ai-analysis', async (req, res) => {
    try {
        const { student, subject } = req.query;

        if (!student || !subject) {
            return res.status(400).json({ error: 'Student and subject are required' });
        }

        // Check AI cache first
        const cached = getCachedAI(student, subject);
        if (cached) {
            return res.json(cached);
        }

        const reports = await readCSV();

        // Filter by student and subject
        const filteredReports = reports.filter(r =>
            r['Student Name'] === student && r.Subject === subject
        );

        if (filteredReports.length === 0) {
            return res.status(404).json({ error: 'No reports found for this combination' });
        }

        // Aggregate all data for analysis
        let totalAttention = 0, totalRetention = 0, totalComprehension = 0;
        let totalBehavior = 0, totalHandwriting = 0, totalConversation = 0;
        let skillFocusMetCount = 0;
        let allWeaknesses = {};
        let allScores = {
            bookMaterials: [], vocabulary: [], classVideo: [],
            homework: [], homeworkVocab: [], weeklyTest: []
        };
        let allNarratives = [];

        filteredReports.forEach(report => {
            // Aggregate ratings
            totalAttention += parseInt(report.Attention) || 0;
            totalRetention += parseInt(report.Retention) || 0;
            totalComprehension += parseInt(report.Comprehension) || 0;
            totalBehavior += parseInt(report.Behavior) || 0;
            totalHandwriting += parseInt(report.Handwriting) || 0;
            totalConversation += parseInt(report.Conversation) || 0;

            // Count skill focus met
            if (report['SF Met'] === 'YES') skillFocusMetCount++;

            // Collect narratives
            if (report.Narrative) {
                allNarratives.push({
                    date: report.Date,
                    narrative: report.Narrative
                });
            }

            // Aggregate weaknesses from skills
            if (report.Skills && typeof report.Skills === 'object') {
                Object.entries(report.Skills).forEach(([skill, data]) => {
                    if (data.weaknesses && Array.isArray(data.weaknesses)) {
                        data.weaknesses.forEach(weakness => {
                            allWeaknesses[weakness] = (allWeaknesses[weakness] || 0) + 1;
                        });
                    }
                });
            }

            // Aggregate scores
            if (report.Scores && typeof report.Scores === 'object') {
                Object.entries(allScores).forEach(([key, arr]) => {
                    if (report.Scores[key]?.score && report.Scores[key]?.total) {
                        const score = parseInt(report.Scores[key].score);
                        const total = parseInt(report.Scores[key].total);
                        if (!isNaN(score) && !isNaN(total) && total > 0) {
                            arr.push({ score, total, percentage: (score / total) * 100 });
                        }
                    }
                });
            }
        });

        const reportCount = filteredReports.length;

        // Calculate averages
        const avgAttention = (totalAttention / reportCount).toFixed(1);
        const avgRetention = (totalRetention / reportCount).toFixed(1);
        const avgComprehension = (totalComprehension / reportCount).toFixed(1);
        const avgBehavior = (totalBehavior / reportCount).toFixed(1);
        const avgHandwriting = (totalHandwriting / reportCount).toFixed(1);
        const avgConversation = (totalConversation / reportCount).toFixed(1);
        const skillFocusMetPercentage = ((skillFocusMetCount / reportCount) * 100).toFixed(1);

        // Top weaknesses
        const topWeaknesses = Object.entries(allWeaknesses)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([weakness, count]) => ({ weakness, count }));

        // Score summaries
        const scoreSummaries = {};
        Object.entries(allScores).forEach(([key, arr]) => {
            if (arr.length > 0) {
                const avgPercentage = arr.reduce((sum, item) => sum + item.percentage, 0) / arr.length;
                scoreSummaries[key] = {
                    average: avgPercentage.toFixed(1),
                    count: arr.length
                };
            }
        });

        // Build prompt for OpenAI - Focus on narratives for final report
        const narrativeSection = allNarratives.length > 0
            ? `\n\nTeacher Narrative Reports (${allNarratives.length} reports):\n${allNarratives.map((n, i) => `\nReport ${i + 1} (${n.date}):\n${n.narrative}`).join('\n')}\n`
            : '';

        const prompt = `You are an educational analyst creating a comprehensive FINAL REPORT for ${student} in ${subject} class based on ${reportCount} reports.

IMPORTANT: Your analysis should PRIMARILY focus on the teacher's narrative reports below, which contain detailed observations and insights about the student's performance, participation, and development over time. Use the quantitative data as supporting evidence to back up the patterns and trends identified in the narratives.

${narrativeSection}

Supporting Quantitative Data:
- Average Attention: ${avgAttention}/5
- Average Retention: ${avgRetention}/5
- Average Comprehension: ${avgComprehension}/5
- Average Behavior: ${avgBehavior}/5
- Average Handwriting: ${avgHandwriting}/5
- Average Conversation: ${avgConversation}/5
- Skill Focus Met: ${skillFocusMetPercentage}% of the time

Top Weaknesses Identified:
${topWeaknesses.map(w => `- ${w.weakness} (appeared ${w.count} times)`).join('\n')}

Score Performance:
${Object.entries(scoreSummaries).map(([key, data]) => `- ${key}: ${data.average}% average (${data.count} assessments)`).join('\n')}

Create a FINAL REPORT with THREE sections (each exactly 2 paragraphs) written AS THE TEACHER:

1. STRENGTHS: Write as the teacher reflecting on the student's key strengths observed throughout the reporting period. Highlight consistent positive patterns in participation, skill development, and achievements. Speak naturally about what you've observed in class.

2. POINTS FOR IMPROVEMENT: Write as the teacher identifying recurring challenges and areas where the student needs development. Discuss patterns you've noticed in participation, skill gaps, and areas where the student has struggled. Be direct and specific about what needs work.

3. RECOMMENDATIONS: Write as the teacher providing concrete, actionable recommendations for the student and parents. Base these on your observations and make them practical and specific to this student's needs. Use "I recommend" or "I suggest" language.

IMPORTANT: Write in first person as the teacher who has been working with this student. DO NOT reference "the narratives" or "the reports" - write as if YOU are the teacher making these observations directly. Write naturally and personally, as if speaking to parents about their child. Avoid meta-references like "based on the narratives" or "according to the data."

Format your response as JSON with this structure:
{
  "strengths": "Two paragraphs synthesizing strengths from narratives...",
  "improvements": "Two paragraphs identifying improvement areas from narratives...",
  "recommendations": "Two paragraphs with actionable recommendations based on narratives..."
}`;

        // Call OpenAI API
        const completion = await openai.chat.completions.create({
            model: 'gpt-4o-mini',
            messages: [
                { role: 'system', content: 'You are a thoughtful, experienced teacher writing a comprehensive final report for a student. Write naturally and personally, as if speaking directly to the student\'s parents. Use first-person perspective ("I have observed", "I recommend", etc.) and avoid any meta-references to data or analysis.' },
                { role: 'user', content: prompt }
            ],
            response_format: { type: 'json_object' },
            temperature: 0.7
        });

        const analysis = JSON.parse(completion.choices[0].message.content);

        const aiResult = {
            student,
            subject,
            reportCount,
            analysis
        };

        // Cache the result
        setCachedAI(student, subject, aiResult);

        res.json(aiResult);

    } catch (error) {
        console.error('Error generating AI analysis:', error);
        res.status(500).json({ error: 'Failed to generate AI analysis' });
    }
});

// Full Report Card endpoint - computes weekly grades for all subjects
// Get date range for a student's reports
app.get('/api/student-date-range', async (req, res) => {
    try {
        const { student } = req.query;
        if (!student) {
            return res.status(400).json({ error: 'Student is required' });
        }
        const reports = await readCSV();
        const studentReports = reports.filter(r => r['Student Name'] === student);
        if (studentReports.length === 0) {
            return res.status(404).json({ error: 'No reports found' });
        }
        const dates = studentReports.map(r => r.Date).filter(Boolean).sort();
        res.json({ min: dates[0], max: dates[dates.length - 1] });
    } catch (error) {
        console.error('Error getting date range:', error);
        res.status(500).json({ error: 'Failed to get date range' });
    }
});

app.get('/api/full-report-card', async (req, res) => {
    try {
        const { student, from, to } = req.query;
        if (!student) {
            return res.status(400).json({ error: 'Student is required' });
        }

        const reports = await readCSV();
        let studentReports = reports.filter(r => r['Student Name'] === student);

        if (studentReports.length === 0) {
            return res.status(404).json({ error: 'No reports found for this student' });
        }

        // Apply date range filter if provided
        if (from) {
            const fromDate = new Date(from);
            fromDate.setHours(0, 0, 0, 0);
            studentReports = studentReports.filter(r => new Date(r.Date) >= fromDate);
        }
        if (to) {
            const toDate = new Date(to);
            toDate.setHours(23, 59, 59, 999);
            studentReports = studentReports.filter(r => new Date(r.Date) <= toDate);
        }

        if (studentReports.length === 0) {
            return res.status(404).json({ error: 'No reports found for this student in the selected date range' });
        }

        // Extract metadata
        const gradeLevel = studentReports[0]['Grade Level'] || '';
        const dates = studentReports.map(r => new Date(r.Date)).sort((a, b) => a - b);
        const firstDate = dates[0];
        const lastDate = dates[dates.length - 1];

        // Compute week boundaries: anchor = Monday on or before first date
        const anchorDay = firstDate.getDay(); // 0=Sun, 1=Mon, ...
        const anchor = new Date(firstDate);
        // Move back to Monday (day 1). If Sunday (0), go back 6 days
        const daysToMonday = anchorDay === 0 ? 6 : anchorDay - 1;
        anchor.setDate(anchor.getDate() - daysToMonday);
        anchor.setHours(0, 0, 0, 0);

        // Determine week number for a given date
        function getWeekNumber(date) {
            const d = new Date(date);
            d.setHours(0, 0, 0, 0);
            const diff = d - anchor;
            return Math.floor(diff / (7 * 24 * 60 * 60 * 1000)) + 1;
        }

        // Find max week
        const maxWeek = getWeekNumber(lastDate);

        // Build week labels
        const weeks = [];
        for (let w = 1; w <= maxWeek; w++) {
            const startDate = new Date(anchor);
            startDate.setDate(startDate.getDate() + (w - 1) * 7);
            const endDate = new Date(startDate);
            endDate.setDate(endDate.getDate() + 6);
            weeks.push({
                number: w,
                label: `Week ${w}`,
                startDate: startDate.toISOString().split('T')[0],
                endDate: endDate.toISOString().split('T')[0]
            });
        }

        // Group reports by subject
        const subjectMap = {};
        studentReports.forEach(report => {
            const subj = report.Subject;
            if (!subj) return;
            if (!subjectMap[subj]) subjectMap[subj] = [];
            subjectMap[subj].push(report);
        });

        // Helper: extract teacher name from "[Name] Full Name" format
        function extractTeacher(teacherStr) {
            if (!teacherStr) return '';
            const match = teacherStr.match(/\[([^\]]+)\]/);
            return match ? match[1] : teacherStr;
        }

        // Letter grade from percentage
        function getLetterGrade(pct) {
            if (pct >= 90) return 'A';
            if (pct >= 85) return 'P';
            if (pct >= 80) return 'AP';
            if (pct >= 75) return 'D';
            return 'B';
        }

        // Compute weekly grades for a subject
        function computeWeeklyGrades(subjectReports) {
            const weeklyGrades = {};
            const weekBuckets = {};

            // Bucket reports by week
            subjectReports.forEach(report => {
                const w = getWeekNumber(new Date(report.Date));
                if (!weekBuckets[w]) weekBuckets[w] = [];
                weekBuckets[w].push(report);
            });

            for (let w = 1; w <= maxWeek; w++) {
                const bucket = weekBuckets[w];
                if (!bucket || bucket.length === 0) continue;

                // Sum scores/totals per category
                const categories = {
                    bookMaterials: { score: 0, total: 0 },
                    vocabulary: { score: 0, total: 0 },
                    classVideo: { score: 0, total: 0 },
                    homework: { score: 0, total: 0 },
                    homeworkVocab: { score: 0, total: 0 },
                    weeklyTest: { score: 0, total: 0 }
                };

                bucket.forEach(report => {
                    const scores = report.Scores || {};
                    Object.keys(categories).forEach(cat => {
                        const s = scores[cat];
                        if (s && s.score !== '' && s.score !== null && s.score !== undefined &&
                            s.total !== '' && s.total !== null && s.total !== undefined) {
                            const scoreVal = parseFloat(s.score);
                            const totalVal = parseFloat(s.total);
                            if (!isNaN(scoreVal) && !isNaN(totalVal) && totalVal > 0) {
                                categories[cat].score += scoreVal;
                                categories[cat].total += totalVal;
                            }
                        }
                    });
                });

                // Calculate percentage per category
                const catPct = {};
                Object.keys(categories).forEach(cat => {
                    if (categories[cat].total > 0) {
                        catPct[cat] = (categories[cat].score / categories[cat].total) * 100;
                    }
                });

                // Group into 4 components
                const components = {};

                // In-Class = avg(bookMaterials%, vocabulary%) if both; else whichever exists
                const hasBook = catPct.bookMaterials !== undefined;
                const hasVocab = catPct.vocabulary !== undefined;
                if (hasBook && hasVocab) {
                    components.inClass = (catPct.bookMaterials + catPct.vocabulary) / 2;
                } else if (hasBook) {
                    components.inClass = catPct.bookMaterials;
                } else if (hasVocab) {
                    components.inClass = catPct.vocabulary;
                }

                // Video
                if (catPct.classVideo !== undefined) {
                    components.video = catPct.classVideo;
                }

                // Homework = avg(homework%, homeworkVocab%) if both; else whichever exists
                const hasHw = catPct.homework !== undefined;
                const hasHwVocab = catPct.homeworkVocab !== undefined;
                if (hasHw && hasHwVocab) {
                    components.homework = (catPct.homework + catPct.homeworkVocab) / 2;
                } else if (hasHw) {
                    components.homework = catPct.homework;
                } else if (hasHwVocab) {
                    components.homework = catPct.homeworkVocab;
                }

                // Weekly Test
                if (catPct.weeklyTest !== undefined) {
                    components.weeklyTest = catPct.weeklyTest;
                }

                // Weighted average with redistribution
                const baseWeights = {
                    inClass: 50,
                    video: 10,
                    homework: 20,
                    weeklyTest: 20
                };

                const presentComponents = Object.keys(components);
                if (presentComponents.length === 0) continue;

                const totalBaseWeight = presentComponents.reduce((sum, c) => sum + baseWeights[c], 0);
                let weightedSum = 0;
                presentComponents.forEach(c => {
                    const redistributedWeight = baseWeights[c] / totalBaseWeight;
                    weightedSum += components[c] * redistributedWeight;
                });

                const percentage = Math.round(weightedSum * 10) / 10;
                weeklyGrades[w] = {
                    letterGrade: getLetterGrade(percentage),
                    percentage
                };
            }

            return weeklyGrades;
        }

        // Build subjects array
        const subjects = Object.keys(subjectMap).sort().map(subjectName => {
            const subjectReports = subjectMap[subjectName];
            const teacher = extractTeacher(subjectReports[0]['Teacher Name']);
            const weeklyGrades = computeWeeklyGrades(subjectReports);

            // Average of weekly percentages
            const weekPcts = Object.values(weeklyGrades).map(g => g.percentage);
            let average = null;
            if (weekPcts.length > 0) {
                const avgPct = Math.round((weekPcts.reduce((a, b) => a + b, 0) / weekPcts.length) * 10) / 10;
                average = { letterGrade: getLetterGrade(avgPct), percentage: avgPct };
            }

            return {
                name: subjectName,
                teacher,
                weeklyGrades,
                average
            };
        });

        // Integrated Vocabulary: sum all vocabulary scores/totals across ALL subjects per week
        const integratedVocab = {};
        for (let w = 1; w <= maxWeek; w++) {
            let totalScore = 0, totalTotal = 0;
            studentReports.forEach(report => {
                const rw = getWeekNumber(new Date(report.Date));
                if (rw !== w) return;
                const scores = report.Scores || {};
                const v = scores.vocabulary;
                if (v && v.score !== '' && v.score !== null && v.score !== undefined &&
                    v.total !== '' && v.total !== null && v.total !== undefined) {
                    const s = parseFloat(v.score);
                    const t = parseFloat(v.total);
                    if (!isNaN(s) && !isNaN(t) && t > 0) {
                        totalScore += s;
                        totalTotal += t;
                    }
                }
            });
            if (totalTotal > 0) {
                const pct = Math.round((totalScore / totalTotal) * 1000) / 10;
                integratedVocab[w] = { letterGrade: getLetterGrade(pct), percentage: pct };
            }
        }

        // Integrated vocab average
        const vocabPcts = Object.values(integratedVocab).map(g => g.percentage);
        let vocabAverage = null;
        if (vocabPcts.length > 0) {
            const avgPct = Math.round((vocabPcts.reduce((a, b) => a + b, 0) / vocabPcts.length) * 10) / 10;
            vocabAverage = { letterGrade: getLetterGrade(avgPct), percentage: avgPct };
        }

        // Format dates
        const formatDate = (d) => d.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

        res.json({
            student,
            gradeLevel,
            duration: {
                from: firstDate.toISOString().split('T')[0],
                to: lastDate.toISOString().split('T')[0],
                fromFormatted: formatDate(firstDate),
                toFormatted: formatDate(lastDate)
            },
            weeks,
            subjects,
            integratedVocabulary: {
                weeklyGrades: integratedVocab,
                average: vocabAverage
            }
        });

    } catch (error) {
        console.error('Error generating full report card:', error);
        res.status(500).json({ error: 'Failed to generate full report card' });
    }
});

// Academic Enabler API endpoints
app.get('/api/academic-enabler', (req, res) => {
    const { student } = req.query;
    const data = readAE();
    if (student) {
        return res.json(data.filter(e => e.student === student));
    }
    res.json(data);
});

app.get('/api/academic-enabler/:id', (req, res) => {
    const data = readAE();
    const entry = data.find(e => e.id === req.params.id);
    if (!entry) return res.status(404).json({ error: 'Entry not found' });
    res.json(entry);
});

app.post('/api/academic-enabler', (req, res) => {
    const data = readAE();
    const entry = {
        id: require('crypto').randomUUID(),
        ...req.body,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    data.push(entry);
    writeAE(data);
    res.status(201).json(entry);
});

app.put('/api/academic-enabler/:id', (req, res) => {
    const data = readAE();
    const idx = data.findIndex(e => e.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Entry not found' });
    data[idx] = { ...data[idx], ...req.body, updatedAt: new Date().toISOString() };
    writeAE(data);
    res.json(data[idx]);
});

app.delete('/api/academic-enabler/:id', (req, res) => {
    const data = readAE();
    const idx = data.findIndex(e => e.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Entry not found' });
    data.splice(idx, 1);
    writeAE(data);
    res.json({ success: true });
});

// Serve academic enabler page
app.get('/academic-enabler', (req, res) => {
    res.sendFile(path.join(__dirname, 'academic-enabler.html'));
});

// Serve report card page
app.get('/report-card', (req, res) => {
    res.sendFile(path.join(__dirname, 'report-card.html'));
});

// Serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🎓 Report Card Data Generator running on http://localhost:${PORT}`);
});
