// Academic Enabler - Frontend Logic

const DOMAINS = [
    {
        name: 'Study Habits',
        number: 'I',
        skills: [
            { name: 'Note-taking', desc: 'Takes complete, organized notes in legible form that can later serve as a study guide' },
            { name: 'Reviewing', desc: 'Reviews class notes frequently to ensure understanding' },
            { name: 'Annotating', desc: 'Uses highlighters, margin notes, or other strategies to identify key information when reading' },
            { name: 'Study Time', desc: 'Allocates enough time to study for tests and quizzes' },
            { name: 'Asking for Teacher Assistance', desc: 'Is willing to seek help from the teacher when he/she has difficulty understanding a topic' }
        ]
    },
    {
        name: 'Organization',
        number: 'II',
        skills: [
            { name: 'Punctuality', desc: 'Arrives to class on time' },
            { name: 'Orderliness', desc: 'Maintains organization of backpack or book bag so that the student can quickly find needed supplies' },
            { name: 'Work Materials', desc: 'Brings the necessary work materials expected for the class' },
            { name: 'Learning Transition', desc: 'Is efficient in switching work materials when transitioning from one learning activity to the next' }
        ]
    },
    {
        name: 'Homework Accomplishment',
        number: 'III',
        skills: [
            { name: 'Homework Completion', desc: 'Writes down homework assignments accurately and completely' },
            { name: 'Time Management', desc: 'Makes use of available time to work on homework and complete it on time' },
            { name: 'Homework Annotations', desc: 'Uses highlighters, margin notes to note questions for further review during class' }
        ]
    },
    {
        name: 'Cooperative Learning Skill',
        number: 'IV',
        skills: [
            { name: 'Discussion Participation', desc: 'Participates in class discussion' },
            { name: 'Group Activity Cooperation', desc: 'Gets along with others during group/pair activities' },
            { name: 'Class Activities Participation', desc: 'Cooperates with the teacher during class activities' },
            { name: 'Group Task Distribution', desc: 'Does his/her fair share of work during group/pair activities' },
            { name: 'Leadership', desc: 'Is willing to take a leadership position during group/pair activities' }
        ]
    },
    {
        name: 'Independent Seat Work',
        number: 'V',
        skills: [
            { name: 'Classroom Behaviour', desc: 'Refrains from distracting behaviours that interrupt the learning of self and others' },
            { name: 'Asking for Teacher Assistance', desc: 'Requests teacher assistance in an appropriate manner' },
            { name: 'Efficiency', desc: 'Uses remaining time to check work or engage in academic activity when classroom work is completed early' },
            { name: 'Output Quality', desc: 'Takes care in completing quality work' },
            { name: 'Dependability', desc: 'Is reliable in turning in assignments done in class' }
        ]
    },
    {
        name: 'Motivation',
        number: 'VI',
        skills: [
            { name: 'Self-Efficacy', desc: 'Has a positive sense of self-efficacy about the class' },
            { name: 'Intrinsic Motivation', desc: 'Displays some apparent intrinsic motivation' },
            { name: 'Extrinsic Motivation', desc: 'Displays some apparent extrinsic motivation' }
        ]
    }
];

// State
let teachers = [];
let initialEntryId = null;
let finalEntryId = null;

// DOM refs
const studentSelect = document.getElementById('studentSelect');
const saveBtn = document.getElementById('saveBtn');
const domainSections = document.getElementById('domainSections');
const formContainer = document.getElementById('formContainer');
const emptyState = document.getElementById('emptyState');
const summaryContent = document.getElementById('summaryContent');
const studentNameDisplay = document.getElementById('studentNameDisplay');
const teacherListDisplay = document.getElementById('teacherListDisplay');
const loadingState = document.getElementById('loadingState');
const toast = document.getElementById('toast');

// Init
document.addEventListener('DOMContentLoaded', async () => {
    await loadStudents(studentSelect);
    setActiveNav();
    updateNavLinks(studentSelect.value);

    studentSelect.addEventListener('change', () => {
        updateNavLinks(studentSelect.value);
        const student = studentSelect.value;
        if (student) {
            loadStudentData(student);
        } else {
            clearForm();
        }
    });
    saveBtn.addEventListener('click', saveEntries);

    // Restore student from URL param (after listeners are attached)
    restoreStudentFromURL(studentSelect);
});

async function loadStudentData(student) {
    loadingState.style.display = 'flex';
    formContainer.style.display = 'none';
    emptyState.style.display = 'none';

    try {
        const [teachersRes, entriesRes] = await Promise.all([
            fetch(`/api/teachers?student=${encodeURIComponent(student)}`),
            fetch(`/api/academic-enabler?student=${encodeURIComponent(student)}`)
        ]);

        teachers = await teachersRes.json();
        const entries = await entriesRes.json();
        const initialEntry = entries.find(e => e.type === 'initial');
        const finalEntry = entries.find(e => e.type === 'final');

        initialEntryId = initialEntry ? initialEntry.id : null;
        finalEntryId = finalEntry ? finalEntry.id : null;

        if (teachers.length === 0) {
            loadingState.style.display = 'none';
            emptyState.style.display = '';
            emptyState.querySelector('p').textContent = 'No teachers found for this student';
            return;
        }

        studentNameDisplay.textContent = student;
        teacherListDisplay.innerHTML = teachers.map(t =>
            `<span class="teacher-tag">T. ${t.nickname || t.fullName}</span>`
        ).join('');

        buildRatingTables();

        if (initialEntry) populateScores(initialEntry, 'initial');
        if (finalEntry) populateScores(finalEntry, 'final');

        updateAverages();
        saveBtn.disabled = false;
        loadingState.style.display = 'none';
        formContainer.style.display = '';

    } catch (e) {
        loadingState.style.display = 'none';
        emptyState.style.display = '';
        showToast('Failed to load data', 'error');
    }
}

function clearForm() {
    formContainer.style.display = 'none';
    emptyState.style.display = '';
    emptyState.querySelector('p').textContent = 'Select a student to view and edit their Academic Enabler assessment';
    teachers = [];
    initialEntryId = null;
    finalEntryId = null;
    saveBtn.disabled = true;
}

function teacherLabel(t) {
    return 'T. ' + (t.nickname || t.fullName);
}

// Layout: Sub-skill | [T1: I | F] | [T2: I | F] | ... | [Avg: I | F] | [Grade: I | F]
function buildRatingTables() {
    domainSections.innerHTML = '';
    DOMAINS.forEach(domain => {
        const section = document.createElement('div');
        section.className = 'domain-section';

        // Row 1: teacher names (colspan 2 each) + Avg (colspan 2) + Grade (colspan 2)
        const headerRow1 = teachers.map(t =>
            `<th colspan="2" class="teacher-group-header">${teacherLabel(t)}</th>`
        ).join('') +
            `<th colspan="2" class="avg-group-header">Average</th>` +
            `<th colspan="2" class="grade-group-header">Grade</th>`;

        // Row 2: I | F repeated for each teacher + Avg + Grade
        const subHeader = (teachers.map(() =>
            `<th class="sub-col sub-initial">I</th><th class="sub-col sub-final">F</th>`
        ).join('')) +
            `<th class="sub-col sub-initial">I</th><th class="sub-col sub-final">F</th>` +
            `<th class="sub-col sub-initial">I</th><th class="sub-col sub-final">F</th>`;

        // Skill rows
        const skillRows = domain.skills.map(skill => {
            const teacherCells = teachers.map(t =>
                `<td class="cell-initial">
                    <input type="number" min="0" max="100" class="score-input"
                        data-phase="initial" data-domain="${domain.name}"
                        data-skill="${skill.name}" data-teacher="${t.fullName}">
                </td>
                <td class="cell-final">
                    <input type="number" min="0" max="100" class="score-input"
                        data-phase="final" data-domain="${domain.name}"
                        data-skill="${skill.name}" data-teacher="${t.fullName}">
                </td>`
            ).join('');

            return `<tr>
                <td><div class="skill-name">${skill.name}<span class="tooltip-trigger" data-tooltip="${skill.desc}">?</span></div></td>
                ${teacherCells}
                <td class="avg-value cell-initial" data-avg="initial-${domain.name}-${skill.name}">-</td>
                <td class="avg-value cell-final" data-avg="final-${domain.name}-${skill.name}">-</td>
                <td class="cell-initial" data-grade="initial-${domain.name}-${skill.name}"><span class="grade-badge grade-none">-</span></td>
                <td class="cell-final" data-grade="final-${domain.name}-${skill.name}"><span class="grade-badge grade-none">-</span></td>
            </tr>`;
        }).join('');

        // Domain avg row
        const emptyTeacherCells = teachers.map(() => '<td class="cell-initial"></td><td class="cell-final"></td>').join('');

        section.innerHTML = `
            <div class="domain-header">
                <span class="domain-number">${domain.number}</span>
                ${domain.name}
            </div>
            <div class="table-scroll">
            <table class="domain-table">
                <thead>
                    <tr>
                        <th rowspan="2" class="skill-col">Sub-skill</th>
                        ${headerRow1}
                    </tr>
                    <tr>${subHeader}</tr>
                </thead>
                <tbody>
                    ${skillRows}
                    <tr class="domain-avg-row">
                        <td><strong>Domain Average</strong></td>
                        ${emptyTeacherCells}
                        <td class="avg-value cell-initial" data-domain-avg-val="initial-${domain.name}">-</td>
                        <td class="avg-value cell-final" data-domain-avg-val="final-${domain.name}">-</td>
                        <td class="cell-initial" data-domain-avg-grade="initial-${domain.name}"><span class="grade-badge grade-none">-</span></td>
                        <td class="cell-final" data-domain-avg-grade="final-${domain.name}"><span class="grade-badge grade-none">-</span></td>
                    </tr>
                </tbody>
            </table>
            </div>
        `;
        domainSections.appendChild(section);
    });

    // Summary
    summaryContent.innerHTML = DOMAINS.map(d =>
        `<div class="summary-card">
            <div class="domain-name">${d.name}</div>
            <div class="summary-pair">
                <div class="summary-phase">
                    <div class="phase-label">Initial</div>
                    <div class="domain-avg" data-summary-avg="initial-${d.name}">-</div>
                    <div data-summary-grade="initial-${d.name}"><span class="grade-badge grade-none">-</span></div>
                </div>
                <div class="summary-phase">
                    <div class="phase-label">Final</div>
                    <div class="domain-avg" data-summary-avg="final-${d.name}">-</div>
                    <div data-summary-grade="final-${d.name}"><span class="grade-badge grade-none">-</span></div>
                </div>
            </div>
        </div>`
    ).join('');

    document.querySelectorAll('.score-input').forEach(input => {
        input.addEventListener('input', () => {
            colorInput(input);
            updateAverages();
        });
    });
}

function populateScores(entry, phase) {
    if (!entry.ratings) return;
    Object.entries(entry.ratings).forEach(([domName, skills]) => {
        Object.entries(skills).forEach(([skillName, teacherScores]) => {
            Object.entries(teacherScores).forEach(([teacher, score]) => {
                const input = document.querySelector(
                    `.score-input[data-phase="${phase}"][data-domain="${domName}"][data-skill="${skillName}"][data-teacher="${teacher}"]`
                );
                if (input) {
                    input.value = score;
                    colorInput(input);
                }
            });
        });
    });
}

function colorInput(input) {
    input.classList.remove('grade-e', 'grade-g', 'grade-p', 'grade-vp');
    const val = parseFloat(input.value);
    if (isNaN(val)) return;
    const grade = getGrade(val);
    if (grade) input.classList.add('grade-' + grade.key);
}

function getGrade(score) {
    if (score >= 90) return { letter: 'E', label: 'Excellent', key: 'e' };
    if (score >= 80) return { letter: 'G', label: 'Good', key: 'g' };
    if (score >= 70) return { letter: 'P', label: 'Poor', key: 'p' };
    return { letter: 'VP', label: 'Very Poor', key: 'vp' };
}

function updateAverages() {
    ['initial', 'final'].forEach(phase => {
        DOMAINS.forEach(domain => {
            let domainTotal = 0;
            let domainCount = 0;

            domain.skills.forEach(skill => {
                const inputs = document.querySelectorAll(
                    `.score-input[data-phase="${phase}"][data-domain="${domain.name}"][data-skill="${skill.name}"]`
                );
                let sum = 0, count = 0;
                inputs.forEach(inp => {
                    const v = parseFloat(inp.value);
                    if (!isNaN(v)) { sum += v; count++; }
                });

                const avgEl = document.querySelector(`[data-avg="${phase}-${domain.name}-${skill.name}"]`);
                const gradeEl = document.querySelector(`[data-grade="${phase}-${domain.name}-${skill.name}"]`);

                if (count > 0) {
                    const avg = sum / count;
                    avgEl.textContent = avg.toFixed(1);
                    const grade = getGrade(avg);
                    gradeEl.innerHTML = `<span class="grade-badge grade-${grade.key}">${grade.letter}</span>`;
                    domainTotal += avg;
                    domainCount++;
                } else {
                    avgEl.textContent = '-';
                    gradeEl.innerHTML = '<span class="grade-badge grade-none">-</span>';
                }
            });

            const domAvgEl = document.querySelector(`[data-domain-avg-val="${phase}-${domain.name}"]`);
            const domGradeEl = document.querySelector(`[data-domain-avg-grade="${phase}-${domain.name}"]`);
            const sumAvgEl = document.querySelector(`[data-summary-avg="${phase}-${domain.name}"]`);
            const sumGradeEl = document.querySelector(`[data-summary-grade="${phase}-${domain.name}"]`);

            if (domainCount > 0) {
                const domAvg = domainTotal / domainCount;
                const grade = getGrade(domAvg);
                domAvgEl.textContent = domAvg.toFixed(1);
                domGradeEl.innerHTML = `<span class="grade-badge grade-${grade.key}">${grade.letter}</span>`;
                sumAvgEl.textContent = domAvg.toFixed(1);
                sumGradeEl.innerHTML = `<span class="grade-badge grade-${grade.key}">${grade.letter}</span>`;
            } else {
                domAvgEl.textContent = '-';
                domGradeEl.innerHTML = '<span class="grade-badge grade-none">-</span>';
                sumAvgEl.textContent = '-';
                sumGradeEl.innerHTML = '<span class="grade-badge grade-none">-</span>';
            }
        });
    });
}

function collectPhaseData(phase) {
    const ratings = {};
    let hasData = false;
    DOMAINS.forEach(domain => {
        ratings[domain.name] = {};
        domain.skills.forEach(skill => {
            ratings[domain.name][skill.name] = {};
            teachers.forEach(t => {
                const input = document.querySelector(
                    `.score-input[data-phase="${phase}"][data-domain="${domain.name}"][data-skill="${skill.name}"][data-teacher="${t.fullName}"]`
                );
                if (input && input.value !== '') {
                    ratings[domain.name][skill.name][t.fullName] = parseFloat(input.value);
                    hasData = true;
                }
            });
        });
    });
    return hasData ? ratings : null;
}

async function saveEntries() {
    const student = studentSelect.value;
    if (!student) return;

    const teacherNames = teachers.map(t => t.fullName);
    let saved = 0;

    for (const phase of ['initial', 'final']) {
        const ratings = collectPhaseData(phase);
        if (!ratings) continue;

        const entryId = phase === 'initial' ? initialEntryId : finalEntryId;
        const body = { student, type: phase, teachers: teacherNames, ratings };

        try {
            let res;
            if (entryId) {
                res = await fetch(`/api/academic-enabler/${entryId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                });
            } else {
                res = await fetch('/api/academic-enabler', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body)
                });
            }
            const result = await res.json();
            if (res.ok) {
                if (phase === 'initial') initialEntryId = result.id;
                else finalEntryId = result.id;
                saved++;
            }
        } catch (e) { /* continue */ }
    }

    if (saved > 0) {
        showToast('Saved successfully', 'success');
    } else {
        showToast('Nothing to save — enter some scores first', 'error');
    }
}

function showToast(message, type) {
    toast.textContent = message;
    toast.className = 'toast ' + type;
    requestAnimationFrame(() => toast.classList.add('show'));
    setTimeout(() => toast.classList.remove('show'), 3000);
}
