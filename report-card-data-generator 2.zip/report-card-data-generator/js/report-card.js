document.addEventListener('DOMContentLoaded', async function () {
    const studentSelect = document.getElementById('studentSelect');
    const generateBtn = document.getElementById('generateBtn');
    const printBtn = document.getElementById('printBtn');
    const loadingState = document.getElementById('loadingState');
    const emptyState = document.getElementById('emptyState');
    const reportCard = document.getElementById('reportCard');

    // Report card elements
    const rcStudentName = document.getElementById('rcStudentName');
    const rcGradeLevel = document.getElementById('rcGradeLevel');
    const rcDuration = document.getElementById('rcDuration');
    const gradeTableHeader = document.getElementById('gradeTableHeader');
    const gradeTableBody = document.getElementById('gradeTableBody');
    const narrativesContainer = document.getElementById('narrativesContainer');
    const dateRangeGroup = document.getElementById('dateRangeGroup');
    const dateFrom = document.getElementById('dateFrom');
    const dateTo = document.getElementById('dateTo');

    let currentData = null;

    // Frontend cache: keyed by "student|from|to" → { data, narratives: { subjectSlug: analysisObj } }
    var reportCache = {};

    // Load students and set up shared nav
    await loadStudents(studentSelect);
    setActiveNav();
    updateNavLinks(studentSelect.value);

    studentSelect.addEventListener('change', function () {
        updateNavLinks(studentSelect.value);
        onStudentChange();
    });
    generateBtn.addEventListener('click', onGenerateClick);
    printBtn.addEventListener('click', function () { window.print(); });

    // Restore student from URL param (after listeners are attached)
    restoreStudentFromURL(studentSelect);

    function getCacheKey() {
        return studentSelect.value + '|' + dateFrom.value + '|' + dateTo.value;
    }

    async function onStudentChange() {
        var student = studentSelect.value;
        if (!student) {
            generateBtn.disabled = true;
            generateBtn.textContent = 'Generate';
            dateRangeGroup.style.display = 'none';
            reportCard.style.display = 'none';
            printBtn.style.display = 'none';
            emptyState.style.display = 'block';
            return;
        }

        // Fetch date range for this student and populate pickers
        try {
            var res = await fetch('/api/student-date-range?student=' + encodeURIComponent(student));
            if (res.ok) {
                var range = await res.json();
                dateFrom.value = range.min;
                dateTo.value = range.max;
                dateRangeGroup.style.display = 'flex';
            }
        } catch (err) {
            console.error('Error fetching date range:', err);
        }

        // If we have a cache for this exact student+date combo, show it immediately
        var key = getCacheKey();
        if (reportCache[key]) {
            showCachedReport(key);
            generateBtn.disabled = false;
            generateBtn.textContent = 'Regenerate';
        } else {
            reportCard.style.display = 'none';
            printBtn.style.display = 'none';
            emptyState.style.display = 'block';
            generateBtn.disabled = false;
            generateBtn.textContent = 'Generate';
        }
    }

    function onGenerateClick() {
        var student = studentSelect.value;
        if (!student) return;

        var key = getCacheKey();
        // If cached, clear cache and fetch fresh
        if (reportCache[key]) {
            delete reportCache[key];
        }
        generateReportCard(student, dateFrom.value, dateTo.value, key);
    }

    function showCachedReport(cacheKey) {
        var cached = reportCache[cacheKey];
        if (!cached) return;

        currentData = cached.data;
        emptyState.style.display = 'none';
        loadingState.style.display = 'none';

        renderHeader(currentData);
        renderGradeTable(currentData);

        // Render narratives from cache (some may still be loading if page was fast)
        renderNarrativesFromCache(currentData.subjects, cached.narratives);

        reportCard.style.display = 'block';
        printBtn.style.display = 'inline-block';

        if (currentData.weeks.length > 8) {
            reportCard.classList.add('landscape-mode');
        } else {
            reportCard.classList.remove('landscape-mode');
        }
    }

    function renderNarrativesFromCache(subjects, narrativeCache) {
        narrativesContainer.innerHTML = '';
        subjects.forEach(function (subj) {
            var card = document.createElement('div');
            card.className = 'narrative-card';
            card.id = 'narrative-' + slugify(subj.name);

            var headerHtml =
                '<div class="narrative-card-header">' +
                    '<h4>' + escapeHtml(subj.name) + '</h4>' +
                    '<span class="narrative-teacher">Teacher: ' + escapeHtml(subj.teacher) + '</span>' +
                '</div>';

            var slug = slugify(subj.name);
            var cached = narrativeCache[slug];

            if (cached && cached.status === 'done') {
                card.innerHTML = headerHtml + buildNarrativeHtml(cached.analysis);
            } else if (cached && cached.status === 'error') {
                card.innerHTML = headerHtml +
                    '<div class="narrative-error">Unable to generate analysis for this subject.</div>';
            } else {
                // Still loading or never started — show as completed placeholder
                card.innerHTML = headerHtml +
                    '<div class="narrative-loading">' +
                        '<div class="mini-spinner"></div>' +
                        '<p>Generating AI analysis...</p>' +
                    '</div>';
            }

            narrativesContainer.appendChild(card);
        });
    }

    async function generateReportCard(student, from, to, cacheKey) {
        // Show loading
        emptyState.style.display = 'none';
        reportCard.style.display = 'none';
        printBtn.style.display = 'none';
        loadingState.style.display = 'block';
        generateBtn.disabled = true;

        try {
            var url = '/api/full-report-card?student=' + encodeURIComponent(student);
            if (from) url += '&from=' + encodeURIComponent(from);
            if (to) url += '&to=' + encodeURIComponent(to);

            var res = await fetch(url);
            if (!res.ok) throw new Error('Failed to generate report card');
            currentData = await res.json();

            // Initialize cache entry
            reportCache[cacheKey] = { data: currentData, narratives: {} };

            renderHeader(currentData);
            renderGradeTable(currentData);
            renderNarrativePlaceholders(currentData.subjects);

            // Show report card
            loadingState.style.display = 'none';
            reportCard.style.display = 'block';
            printBtn.style.display = 'inline-block';
            generateBtn.disabled = false;
            generateBtn.textContent = 'Regenerate';

            // Toggle landscape mode for many weeks
            if (currentData.weeks.length > 8) {
                reportCard.classList.add('landscape-mode');
            } else {
                reportCard.classList.remove('landscape-mode');
            }

            // Fire AI analysis for all subjects in parallel (max 3 concurrent)
            loadNarratives(student, currentData.subjects, cacheKey);
        } catch (err) {
            console.error('Error generating report card:', err);
            loadingState.style.display = 'none';
            emptyState.style.display = 'block';
            generateBtn.disabled = false;
            generateBtn.textContent = 'Generate';
            alert('Error generating report card: ' + err.message);
        }
    }

    function renderHeader(data) {
        rcStudentName.textContent = data.student;
        rcGradeLevel.textContent = data.gradeLevel;
        rcDuration.textContent = data.duration.fromFormatted + ' - ' + data.duration.toFormatted;
    }

    function renderGradeTable(data) {
        // Build header: Subject | Teacher | Week 1..N | Average
        gradeTableHeader.innerHTML = '';

        var thSubject = document.createElement('th');
        thSubject.className = 'rc-subject-col';
        thSubject.textContent = 'Subject';
        gradeTableHeader.appendChild(thSubject);

        var thTeacher = document.createElement('th');
        thTeacher.className = 'rc-teacher-col';
        thTeacher.textContent = 'Teacher';
        gradeTableHeader.appendChild(thTeacher);

        data.weeks.forEach(function (w) {
            var th = document.createElement('th');
            th.textContent = w.label;
            th.title = w.startDate + ' to ' + w.endDate;
            gradeTableHeader.appendChild(th);
        });

        var thAvg = document.createElement('th');
        thAvg.className = 'rc-avg-col';
        thAvg.textContent = 'Average';
        gradeTableHeader.appendChild(thAvg);

        // Build body rows
        gradeTableBody.innerHTML = '';

        // Subject rows
        data.subjects.forEach(function (subj) {
            var tr = document.createElement('tr');

            // Subject name
            var tdName = document.createElement('td');
            tdName.textContent = subj.name;
            tr.appendChild(tdName);

            // Teacher
            var tdTeacher = document.createElement('td');
            tdTeacher.textContent = subj.teacher;
            tr.appendChild(tdTeacher);

            // Weekly grades
            data.weeks.forEach(function (w) {
                var td = document.createElement('td');
                var grade = subj.weeklyGrades[w.number];
                if (grade) {
                    td.className = 'grade-cell-bg grade-bg-' + grade.letterGrade;
                    td.innerHTML = '<div class="grade-cell">' +
                        '<span class="grade-letter grade-' + grade.letterGrade + '">' + grade.letterGrade + '</span>' +
                        '<span class="grade-pct">' + grade.percentage + '%</span>' +
                        '</div>';
                } else {
                    td.innerHTML = '<span class="grade-empty">-</span>';
                }
                tr.appendChild(td);
            });

            // Average
            var tdAvg = document.createElement('td');
            if (subj.average) {
                tdAvg.className = 'grade-cell-bg grade-bg-' + subj.average.letterGrade;
                tdAvg.innerHTML = '<div class="grade-cell">' +
                    '<span class="grade-letter grade-' + subj.average.letterGrade + '">' + subj.average.letterGrade + '</span>' +
                    '<span class="grade-pct">' + subj.average.percentage + '%</span>' +
                    '</div>';
            } else {
                tdAvg.innerHTML = '<span class="grade-empty">-</span>';
            }
            tr.appendChild(tdAvg);

            gradeTableBody.appendChild(tr);
        });

        // Integrated Vocabulary row
        var vocabRow = document.createElement('tr');
        vocabRow.className = 'rc-vocab-row';

        var tdVocabName = document.createElement('td');
        tdVocabName.textContent = 'Integrated Vocabulary';
        vocabRow.appendChild(tdVocabName);

        var tdVocabTeacher = document.createElement('td');
        tdVocabTeacher.textContent = 'All';
        vocabRow.appendChild(tdVocabTeacher);

        data.weeks.forEach(function (w) {
            var td = document.createElement('td');
            var grade = data.integratedVocabulary.weeklyGrades[w.number];
            if (grade) {
                td.className = 'grade-cell-bg grade-bg-' + grade.letterGrade;
                td.innerHTML = '<div class="grade-cell">' +
                    '<span class="grade-letter grade-' + grade.letterGrade + '">' + grade.letterGrade + '</span>' +
                    '<span class="grade-pct">' + grade.percentage + '%</span>' +
                    '</div>';
            } else {
                td.innerHTML = '<span class="grade-empty">-</span>';
            }
            vocabRow.appendChild(td);
        });

        // Vocab average
        var tdVocabAvg = document.createElement('td');
        if (data.integratedVocabulary.average) {
            var avg = data.integratedVocabulary.average;
            tdVocabAvg.className = 'grade-cell-bg grade-bg-' + avg.letterGrade;
            tdVocabAvg.innerHTML = '<div class="grade-cell">' +
                '<span class="grade-letter grade-' + avg.letterGrade + '">' + avg.letterGrade + '</span>' +
                '<span class="grade-pct">' + avg.percentage + '%</span>' +
                '</div>';
        } else {
            tdVocabAvg.innerHTML = '<span class="grade-empty">-</span>';
        }
        vocabRow.appendChild(tdVocabAvg);

        gradeTableBody.appendChild(vocabRow);
    }

    function renderNarrativePlaceholders(subjects) {
        narrativesContainer.innerHTML = '';
        subjects.forEach(function (subj) {
            var card = document.createElement('div');
            card.className = 'narrative-card';
            card.id = 'narrative-' + slugify(subj.name);

            card.innerHTML =
                '<div class="narrative-card-header">' +
                    '<h4>' + escapeHtml(subj.name) + '</h4>' +
                    '<span class="narrative-teacher">Teacher: ' + escapeHtml(subj.teacher) + '</span>' +
                '</div>' +
                '<div class="narrative-loading">' +
                    '<div class="mini-spinner"></div>' +
                    '<p>Generating AI analysis...</p>' +
                '</div>';

            narrativesContainer.appendChild(card);
        });
    }

    async function loadNarratives(student, subjects, cacheKey) {
        // Process with max 3 concurrent requests
        var queue = subjects.slice();
        var active = 0;
        var maxConcurrent = 3;

        function processNext() {
            while (active < maxConcurrent && queue.length > 0) {
                var subj = queue.shift();
                active++;
                fetchNarrative(student, subj.name, cacheKey).then(function () {
                    active--;
                    processNext();
                });
            }
        }

        processNext();
    }

    async function fetchNarrative(student, subjectName, cacheKey) {
        var cardId = 'narrative-' + slugify(subjectName);
        var card = document.getElementById(cardId);
        if (!card) return;

        var slug = slugify(subjectName);

        try {
            var res = await fetch('/api/ai-analysis?student=' + encodeURIComponent(student) + '&subject=' + encodeURIComponent(subjectName));
            if (!res.ok) throw new Error('Failed');
            var result = await res.json();

            // Cache the narrative
            if (reportCache[cacheKey]) {
                reportCache[cacheKey].narratives[slug] = { status: 'done', analysis: result.analysis };
            }

            renderNarrative(card, result.analysis);
        } catch (err) {
            console.error('AI analysis error for ' + subjectName + ':', err);

            // Cache the error too so we don't retry on re-view
            if (reportCache[cacheKey]) {
                reportCache[cacheKey].narratives[slug] = { status: 'error' };
            }

            var loading = card.querySelector('.narrative-loading');
            if (loading) {
                loading.outerHTML = '<div class="narrative-error">Unable to generate analysis for this subject.</div>';
            }
        }
    }

    function buildNarrativeHtml(analysis) {
        return '<div class="narrative-subsection strengths">' +
                '<h5>Strengths</h5>' +
                formatParagraphs(analysis.strengths) +
            '</div>' +
            '<div class="narrative-subsection improvements">' +
                '<h5>Points for Improvement</h5>' +
                formatParagraphs(analysis.improvements) +
            '</div>' +
            '<div class="narrative-subsection recommendations">' +
                '<h5>Recommendations</h5>' +
                formatParagraphs(analysis.recommendations) +
            '</div>';
    }

    function renderNarrative(card, analysis) {
        var loading = card.querySelector('.narrative-loading');
        if (!loading) return;
        loading.outerHTML = buildNarrativeHtml(analysis);
    }

    function formatParagraphs(text) {
        if (!text) return '<p>No data available.</p>';
        var paragraphs = text.split('\n\n').filter(function (p) { return p.trim(); });
        if (paragraphs.length === 0) return '<p>No data available.</p>';
        return paragraphs.map(function (p) { return '<p>' + escapeHtml(p.trim()) + '</p>'; }).join('');
    }

    function slugify(str) {
        return str.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
});
