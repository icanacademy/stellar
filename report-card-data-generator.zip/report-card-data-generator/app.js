const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
const cors = require('cors');
const OpenAI = require('openai');
require('dotenv').config();

const app = express();
const PORT = 1443;

// Initialize OpenAI
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

app.use(cors());
app.use(express.json());

// Serve static files - specific routes first before general
app.use('/assets', express.static(path.join(__dirname, 'assets')));
app.use('/css', express.static(path.join(__dirname, 'css')));
app.use('/js', express.static(path.join(__dirname, 'js')));
// Serve root directory files (index.html, etc)
app.use(express.static(__dirname));

// Path to the CSV file
const CSV_PATH = path.join(__dirname, '..', 'teacher-report-generator', 'reports.csv');

// Function to read and parse CSV
function readCSV() {
    return new Promise((resolve, reject) => {
        const results = [];
        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (data) => {
                // Parse Skills JSON if it exists
                if (data.Skills) {
                    try {
                        data.Skills = JSON.parse(data.Skills);
                    } catch (e) {
                        data.Skills = {};
                    }
                }

                // Parse Scores JSON if it exists
                if (data.Scores) {
                    try {
                        data.Scores = JSON.parse(data.Scores);
                    } catch (e) {
                        data.Scores = {};
                    }
                }

                results.push(data);
            })
            .on('end', () => resolve(results))
            .on('error', (error) => reject(error));
    });
}

// Get unique students
app.get('/api/students', async (req, res) => {
    try {
        const reports = await readCSV();
        const students = [...new Set(reports.map(r => r['Student Name']))].filter(Boolean).sort();
        res.json(students);
    } catch (error) {
        console.error('Error reading students:', error);
        res.status(500).json({ error: 'Failed to read student data' });
    }
});

// Get unique subjects (optionally filtered by student)
app.get('/api/subjects', async (req, res) => {
    try {
        const reports = await readCSV();
        const { student } = req.query;

        let filtered = reports;
        if (student) {
            filtered = reports.filter(r => r['Student Name'] === student);
        }

        const subjects = [...new Set(filtered.map(r => r.Subject))].filter(Boolean).sort();
        res.json(subjects);
    } catch (error) {
        console.error('Error reading subjects:', error);
        res.status(500).json({ error: 'Failed to read subject data' });
    }
});

// Get all reports (optionally filtered by student)
app.get('/api/reports', async (req, res) => {
    try {
        const reports = await readCSV();
        const { student } = req.query;

        if (student) {
            const filtered = reports.filter(r => r['Student Name'] === student);
            res.json(filtered);
        } else {
            res.json(reports);
        }
    } catch (error) {
        console.error('Error reading reports:', error);
        res.status(500).json({ error: 'Failed to read reports' });
    }
});

// Get filtered report card data
app.get('/api/report-card-data', async (req, res) => {
    try {
        const { student, subject } = req.query;

        if (!student || !subject) {
            return res.status(400).json({ error: 'Student and subject are required' });
        }

        const reports = await readCSV();

        // Filter by student and subject
        const filteredReports = reports.filter(r =>
            r['Student Name'] === student && r.Subject === subject
        );

        // Sort by date (oldest first)
        filteredReports.sort((a, b) => new Date(a.Date) - new Date(b.Date));

        // Format the data for table display
        const tableData = filteredReports.map(report => {
            const scores = report.Scores || {};

            // Helper function to handle empty strings and missing values
            const getValue = (value) => {
                if (value === null || value === undefined || value === '') {
                    return '';
                }
                return value;
            };

            // Extract name from brackets [Name] format
            let teacherName = report['Teacher Name'] || '-';
            if (teacherName !== '-') {
                const match = teacherName.match(/\[([^\]]+)\]/);
                if (match) {
                    teacherName = match[1];
                }
            }

            return {
                date: report.Date || '-',
                bookMaterialsScore: getValue(scores.bookMaterials?.score),
                bookMaterialsTotal: getValue(scores.bookMaterials?.total),
                vocabularyScore: getValue(scores.vocabulary?.score),
                vocabularyTotal: getValue(scores.vocabulary?.total),
                classVideoScore: getValue(scores.classVideo?.score),
                classVideoTotal: getValue(scores.classVideo?.total),
                homeworkScore: getValue(scores.homework?.score),
                homeworkTotal: getValue(scores.homework?.total),
                homeworkVocabScore: getValue(scores.homeworkVocab?.score),
                homeworkVocabTotal: getValue(scores.homeworkVocab?.total),
                weeklyTestScore: getValue(scores.weeklyTest?.score),
                weeklyTestTotal: getValue(scores.weeklyTest?.total),
                teacherName: teacherName
            };
        });

        res.json({
            student,
            subject,
            count: tableData.length,
            data: tableData
        });
    } catch (error) {
        console.error('Error generating report card data:', error);
        res.status(500).json({ error: 'Failed to generate report card data' });
    }
});

// AI Analysis endpoint
app.get('/api/ai-analysis', async (req, res) => {
    try {
        const { student, subject } = req.query;

        if (!student || !subject) {
            return res.status(400).json({ error: 'Student and subject are required' });
        }

        const reports = await readCSV();

        // Filter by student and subject
        const filteredReports = reports.filter(r =>
            r['Student Name'] === student && r.Subject === subject
        );

        if (filteredReports.length === 0) {
            return res.status(404).json({ error: 'No reports found for this combination' });
        }

        // Aggregate all data for analysis
        let totalAttention = 0, totalRetention = 0, totalComprehension = 0;
        let totalBehavior = 0, totalHandwriting = 0, totalConversation = 0;
        let skillFocusMetCount = 0;
        let allWeaknesses = {};
        let allScores = {
            bookMaterials: [], vocabulary: [], classVideo: [],
            homework: [], homeworkVocab: [], weeklyTest: []
        };
        let allNarratives = [];

        filteredReports.forEach(report => {
            // Aggregate ratings
            totalAttention += parseInt(report.Attention) || 0;
            totalRetention += parseInt(report.Retention) || 0;
            totalComprehension += parseInt(report.Comprehension) || 0;
            totalBehavior += parseInt(report.Behavior) || 0;
            totalHandwriting += parseInt(report.Handwriting) || 0;
            totalConversation += parseInt(report.Conversation) || 0;

            // Count skill focus met
            if (report['SF Met'] === 'YES') skillFocusMetCount++;

            // Collect narratives
            if (report.Narrative) {
                allNarratives.push({
                    date: report.Date,
                    narrative: report.Narrative
                });
            }

            // Aggregate weaknesses from skills
            if (report.Skills && typeof report.Skills === 'object') {
                Object.entries(report.Skills).forEach(([skill, data]) => {
                    if (data.weaknesses && Array.isArray(data.weaknesses)) {
                        data.weaknesses.forEach(weakness => {
                            allWeaknesses[weakness] = (allWeaknesses[weakness] || 0) + 1;
                        });
                    }
                });
            }

            // Aggregate scores
            if (report.Scores && typeof report.Scores === 'object') {
                Object.entries(allScores).forEach(([key, arr]) => {
                    if (report.Scores[key]?.score && report.Scores[key]?.total) {
                        const score = parseInt(report.Scores[key].score);
                        const total = parseInt(report.Scores[key].total);
                        if (!isNaN(score) && !isNaN(total) && total > 0) {
                            arr.push({ score, total, percentage: (score / total) * 100 });
                        }
                    }
                });
            }
        });

        const reportCount = filteredReports.length;

        // Calculate averages
        const avgAttention = (totalAttention / reportCount).toFixed(1);
        const avgRetention = (totalRetention / reportCount).toFixed(1);
        const avgComprehension = (totalComprehension / reportCount).toFixed(1);
        const avgBehavior = (totalBehavior / reportCount).toFixed(1);
        const avgHandwriting = (totalHandwriting / reportCount).toFixed(1);
        const avgConversation = (totalConversation / reportCount).toFixed(1);
        const skillFocusMetPercentage = ((skillFocusMetCount / reportCount) * 100).toFixed(1);

        // Top weaknesses
        const topWeaknesses = Object.entries(allWeaknesses)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5)
            .map(([weakness, count]) => ({ weakness, count }));

        // Score summaries
        const scoreSummaries = {};
        Object.entries(allScores).forEach(([key, arr]) => {
            if (arr.length > 0) {
                const avgPercentage = arr.reduce((sum, item) => sum + item.percentage, 0) / arr.length;
                scoreSummaries[key] = {
                    average: avgPercentage.toFixed(1),
                    count: arr.length
                };
            }
        });

        // Build prompt for OpenAI - Focus on narratives for final report
        const narrativeSection = allNarratives.length > 0
            ? `\n\nTeacher Narrative Reports (${allNarratives.length} reports):\n${allNarratives.map((n, i) => `\nReport ${i + 1} (${n.date}):\n${n.narrative}`).join('\n')}\n`
            : '';

        const prompt = `You are an educational analyst creating a comprehensive FINAL REPORT for ${student} in ${subject} class based on ${reportCount} reports.

IMPORTANT: Your analysis should PRIMARILY focus on the teacher's narrative reports below, which contain detailed observations and insights about the student's performance, participation, and development over time. Use the quantitative data as supporting evidence to back up the patterns and trends identified in the narratives.

${narrativeSection}

Supporting Quantitative Data:
- Average Attention: ${avgAttention}/5
- Average Retention: ${avgRetention}/5
- Average Comprehension: ${avgComprehension}/5
- Average Behavior: ${avgBehavior}/5
- Average Handwriting: ${avgHandwriting}/5
- Average Conversation: ${avgConversation}/5
- Skill Focus Met: ${skillFocusMetPercentage}% of the time

Top Weaknesses Identified:
${topWeaknesses.map(w => `- ${w.weakness} (appeared ${w.count} times)`).join('\n')}

Score Performance:
${Object.entries(scoreSummaries).map(([key, data]) => `- ${key}: ${data.average}% average (${data.count} assessments)`).join('\n')}

Create a FINAL REPORT with THREE sections (each exactly 2 paragraphs) written AS THE TEACHER:

1. STRENGTHS: Write as the teacher reflecting on the student's key strengths observed throughout the reporting period. Highlight consistent positive patterns in participation, skill development, and achievements. Speak naturally about what you've observed in class.

2. POINTS FOR IMPROVEMENT: Write as the teacher identifying recurring challenges and areas where the student needs development. Discuss patterns you've noticed in participation, skill gaps, and areas where the student has struggled. Be direct and specific about what needs work.

3. RECOMMENDATIONS: Write as the teacher providing concrete, actionable recommendations for the student and parents. Base these on your observations and make them practical and specific to this student's needs. Use "I recommend" or "I suggest" language.

IMPORTANT: Write in first person as the teacher who has been working with this student. DO NOT reference "the narratives" or "the reports" - write as if YOU are the teacher making these observations directly. Write naturally and personally, as if speaking to parents about their child. Avoid meta-references like "based on the narratives" or "according to the data."

Format your response as JSON with this structure:
{
  "strengths": "Two paragraphs synthesizing strengths from narratives...",
  "improvements": "Two paragraphs identifying improvement areas from narratives...",
  "recommendations": "Two paragraphs with actionable recommendations based on narratives..."
}`;

        // Call OpenAI API
        const completion = await openai.chat.completions.create({
            model: 'gpt-4o-mini',
            messages: [
                { role: 'system', content: 'You are a thoughtful, experienced teacher writing a comprehensive final report for a student. Write naturally and personally, as if speaking directly to the student\'s parents. Use first-person perspective ("I have observed", "I recommend", etc.) and avoid any meta-references to data or analysis.' },
                { role: 'user', content: prompt }
            ],
            response_format: { type: 'json_object' },
            temperature: 0.7
        });

        const analysis = JSON.parse(completion.choices[0].message.content);

        res.json({
            student,
            subject,
            reportCount,
            analysis
        });

    } catch (error) {
        console.error('Error generating AI analysis:', error);
        res.status(500).json({ error: 'Failed to generate AI analysis' });
    }
});

// Serve index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🎓 Report Card Data Generator running on http://localhost:${PORT}`);
});
