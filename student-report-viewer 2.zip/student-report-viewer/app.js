const express = require('express');
const cors = require('cors');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
const OpenAI = require('openai');
require('dotenv').config({ path: path.join(__dirname, '../teacher-report-generator/.env') });

const app = express();
const port = 1442;

// Initialize OpenAI
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Path to the CSV file in the parent app
const CSV_PATH = path.join(__dirname, '../teacher-report-generator/reports.csv');

// Helper function to parse SF Met field (handles both old YES/NO and new JSON format)
function parseSfMet(sfMetValue, skillFocusValue) {
    const result = {
        overallMet: false,
        allMet: true,
        anyMet: false,
        perSkill: {},
        metCount: 0,
        notMetCount: 0,
        totalCount: 0
    };

    if (!sfMetValue) {
        return result;
    }

    // Try to parse as JSON first (new format)
    if (sfMetValue.startsWith('{') && sfMetValue.endsWith('}')) {
        try {
            const parsed = JSON.parse(sfMetValue);
            for (const [skill, met] of Object.entries(parsed)) {
                result.perSkill[skill] = met === true;
                result.totalCount++;
                if (met === true) {
                    result.metCount++;
                    result.anyMet = true;
                } else {
                    result.notMetCount++;
                    result.allMet = false;
                }
            }
            result.overallMet = result.anyMet;
            return result;
        } catch (e) {
            // Fall through to old format handling
        }
    }

    // Old format: YES/NO
    const isMet = sfMetValue === 'YES';
    result.overallMet = isMet;
    result.allMet = isMet;
    result.anyMet = isMet;
    result.metCount = isMet ? 1 : 0;
    result.notMetCount = isMet ? 0 : 1;
    result.totalCount = 1;

    // If we have skill focus values, create per-skill entries with same met status
    if (skillFocusValue && skillFocusValue.trim()) {
        const skills = skillFocusValue.split(',').map(s => s.trim()).filter(s => s);
        result.totalCount = skills.length || 1;
        result.metCount = isMet ? result.totalCount : 0;
        result.notMetCount = isMet ? 0 : result.totalCount;
        skills.forEach(skill => {
            result.perSkill[skill] = isMet;
        });
    }

    return result;
}

// Helper function to deduplicate reports
// Keeps only the latest entry for each Student + Date + Subject combination
// Assumes later rows in CSV are corrections/updates to earlier ones
function deduplicateReports(reports) {
    const seen = new Map();

    // Process in order - later entries override earlier ones
    reports.forEach((report, index) => {
        const key = `${report['Student Name']}|${report['Date']}|${report['Subject']}`;
        // Store the report with its original index to maintain order
        seen.set(key, { report, index });
    });

    // Convert back to array and sort by original index to maintain chronological order
    return Array.from(seen.values())
        .sort((a, b) => a.index - b.index)
        .map(item => item.report);
}

// Endpoint to get all unique students
app.get('/api/students', async (req, res) => {
    try {
        const students = new Set();

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                if (row['Student Name']) {
                    students.add(row['Student Name']);
                }
            })
            .on('end', () => {
                res.json(Array.from(students).sort());
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get all teachers
app.get('/api/teachers', async (req, res) => {
    try {
        const teachers = new Set();

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                if (row['Teacher Name']) {
                    teachers.add(row['Teacher Name']);
                }
            })
            .on('end', () => {
                res.json(Array.from(teachers).sort());
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get all subjects
app.get('/api/subjects', async (req, res) => {
    try {
        const subjects = new Set();

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                if (row['Subject']) {
                    subjects.add(row['Subject']);
                }
            })
            .on('end', () => {
                res.json(Array.from(subjects).sort());
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get reports with filters
app.get('/api/reports', async (req, res) => {
    try {
        const { student, teacher, subject, startDate, endDate } = req.query;
        const reports = [];

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                // Apply filters
                let include = true;

                if (student && row['Student Name'] !== student) include = false;
                if (teacher && row['Teacher Name'] !== teacher) include = false;
                if (subject && row['Subject'] !== subject) include = false;
                if (startDate && row['Date'] < startDate) include = false;
                if (endDate && row['Date'] > endDate) include = false;

                if (include) {
                    // Parse JSON fields
                    try {
                        row.Skills = row.Skills ? JSON.parse(row.Skills) : {};
                        row.Scores = row.Scores ? JSON.parse(row.Scores) : {};
                    } catch (e) {
                        console.error('Error parsing JSON:', e);
                        row.Skills = {};
                        row.Scores = {};
                    }
                    reports.push(row);
                }
            })
            .on('end', () => {
                // Deduplicate reports (keep latest entry for each Student+Date+Subject)
                const deduped = deduplicateReports(reports);

                // Sort by date (oldest first)
                deduped.sort((a, b) => new Date(a.Date) - new Date(b.Date));
                res.json(deduped);
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get analytics for a student
app.get('/api/analytics', async (req, res) => {
    try {
        const { student, teacher, subject, startDate, endDate } = req.query;
        if (!student) {
            return res.status(400).json({ error: 'Student name required' });
        }

        const reports = [];

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                // Apply same filters as /api/reports
                let include = row['Student Name'] === student;

                if (include && teacher && row['Teacher Name'] !== teacher) include = false;
                if (include && subject && row['Subject'] !== subject) include = false;
                if (include && startDate && row['Date'] < startDate) include = false;
                if (include && endDate && row['Date'] > endDate) include = false;

                if (include) {
                    reports.push(row);
                }
            })
            .on('end', () => {
                // Deduplicate reports (keep latest entry for each Student+Date+Subject)
                const dedupedReports = deduplicateReports(reports);

                // Calculate analytics
                const analytics = {
                    totalReports: dedupedReports.length,
                    dateRange: {
                        earliest: dedupedReports.length > 0 ? dedupedReports[dedupedReports.length - 1].Date : null,
                        latest: dedupedReports.length > 0 ? dedupedReports[0].Date : null
                    },
                    averageRatings: {
                        attention: 0,
                        retention: 0,
                        comprehension: 0,
                        behavior: 0,
                        handwriting: 0,
                        conversation: 0
                    },
                    subjectsCount: {},
                    teachersCount: {},
                    materialsBySubject: {},
                    lessonsBySubject: {},  // Learning progress tracking
                    learningTimeline: [],   // Chronological lesson history
                    textbookPerformance: {},  // Performance metrics per textbook
                    lessonPerformance: [],    // Performance metrics per lesson
                    skillFocusMet: { yes: 0, no: 0 }
                };

                if (dedupedReports.length === 0) {
                    return res.json(analytics);
                }

                // Calculate averages
                let sum = {
                    attention: 0,
                    retention: 0,
                    comprehension: 0,
                    behavior: 0,
                    handwriting: 0,
                    conversation: 0
                };

                dedupedReports.forEach(report => {
                    // Ratings
                    sum.attention += parseInt(report.Attention) || 0;
                    sum.retention += parseInt(report.Retention) || 0;
                    sum.comprehension += parseInt(report.Comprehension) || 0;
                    sum.behavior += parseInt(report.Behavior) || 0;
                    sum.handwriting += parseInt(report.Handwriting) || 0;
                    sum.conversation += parseInt(report.Conversation) || 0;

                    // Subject counts
                    analytics.subjectsCount[report.Subject] = (analytics.subjectsCount[report.Subject] || 0) + 1;

                    // Teacher counts
                    analytics.teachersCount[report['Teacher Name']] = (analytics.teachersCount[report['Teacher Name']] || 0) + 1;

                    // Materials by Subject
                    if (report.Subject) {
                        if (!analytics.materialsBySubject[report.Subject]) {
                            analytics.materialsBySubject[report.Subject] = [];
                        }
                        // Ensure Materials is a string before adding
                        const material = typeof report.Materials === 'string' ? report.Materials : '';
                        if (material && material.trim() !== '' && material !== 'N/A') {
                            analytics.materialsBySubject[report.Subject].push(material.trim());
                        }
                    }

                    // Lessons by Subject (track learning progress)
                    if (report.Subject && report['Current Lesson']) {
                        if (!analytics.lessonsBySubject[report.Subject]) {
                            analytics.lessonsBySubject[report.Subject] = [];
                        }
                        const lesson = report['Current Lesson'].trim();
                        if (lesson && lesson !== 'N/A' && lesson !== '-') {
                            // Add unique lessons only
                            if (!analytics.lessonsBySubject[report.Subject].includes(lesson)) {
                                analytics.lessonsBySubject[report.Subject].push(lesson);
                            }
                        }
                    }

                    // Parse SF Met (handles both old YES/NO and new JSON format)
                    const sfMetParsed = parseSfMet(report['SF Met'], report['Skill Focus']);

                    // Learning Timeline (chronological)
                    if (report['Current Lesson'] && report['Current Lesson'].trim()) {
                        analytics.learningTimeline.push({
                            date: report.Date,
                            subject: report.Subject,
                            lesson: report['Current Lesson'].trim(),
                            skillFocus: report['Skill Focus'] || '',
                            sfMet: sfMetParsed.overallMet,
                            sfMetDetails: sfMetParsed.perSkill,
                            homework: report.Homework || ''
                        });
                    }

                    // Calculate performance metrics for this report
                    const avgRating = (
                        (parseInt(report.Attention) || 0) +
                        (parseInt(report.Retention) || 0) +
                        (parseInt(report.Comprehension) || 0) +
                        (parseInt(report.Behavior) || 0) +
                        (parseInt(report.Handwriting) || 0) +
                        (parseInt(report.Conversation) || 0)
                    ) / 6;

                    // Calculate score percentage if scores exist
                    let scorePercent = null;
                    try {
                        const scores = report.Scores ? (typeof report.Scores === 'string' ? JSON.parse(report.Scores) : report.Scores) : {};
                        let totalScore = 0, totalPossible = 0;
                        Object.values(scores).forEach(s => {
                            if (s && s.score && s.total && parseInt(s.total) > 0) {
                                totalScore += parseInt(s.score) || 0;
                                totalPossible += parseInt(s.total) || 0;
                            }
                        });
                        if (totalPossible > 0) {
                            scorePercent = Math.round((totalScore / totalPossible) * 100);
                        }
                    } catch (e) {}

                    // Textbook Performance tracking
                    const textbook = typeof report.Materials === 'string' ? report.Materials.trim() : '';
                    if (textbook && textbook !== '' && textbook !== 'N/A') {
                        if (!analytics.textbookPerformance[textbook]) {
                            analytics.textbookPerformance[textbook] = {
                                subject: report.Subject,
                                sessions: 0,
                                totalRating: 0,
                                totalScorePercent: 0,
                                scoreCount: 0,
                                sfMetCount: 0,
                                sfTotalCount: 0,
                                lessons: []
                            };
                        }
                        const tp = analytics.textbookPerformance[textbook];
                        tp.sessions++;
                        tp.totalRating += avgRating;
                        if (scorePercent !== null) {
                            tp.totalScorePercent += scorePercent;
                            tp.scoreCount++;
                        }
                        tp.sfMetCount += sfMetParsed.metCount;
                        tp.sfTotalCount += sfMetParsed.totalCount;
                        if (report['Current Lesson'] && !tp.lessons.includes(report['Current Lesson'].trim())) {
                            tp.lessons.push(report['Current Lesson'].trim());
                        }
                    }

                    // Lesson Performance tracking
                    const lesson = report['Current Lesson'] ? report['Current Lesson'].trim() : '';
                    if (lesson && lesson !== '' && lesson !== 'N/A' && lesson !== '-') {
                        analytics.lessonPerformance.push({
                            date: report.Date,
                            subject: report.Subject,
                            textbook: textbook || 'Not specified',
                            lesson: lesson,
                            avgRating: Math.round(avgRating * 10) / 10,
                            scorePercent: scorePercent,
                            sfMet: sfMetParsed.overallMet,
                            sfMetDetails: sfMetParsed.perSkill,
                            skillFocus: report['Skill Focus'] || ''
                        });
                    }

                    // Skill focus met (count per-skill for accurate tracking)
                    analytics.skillFocusMet.yes += sfMetParsed.metCount;
                    analytics.skillFocusMet.no += sfMetParsed.notMetCount;
                });

                // Calculate averages
                Object.keys(sum).forEach(key => {
                    analytics.averageRatings[key] = (sum[key] / dedupedReports.length).toFixed(2);
                });

                // Finalize textbook performance averages
                Object.keys(analytics.textbookPerformance).forEach(textbook => {
                    const tp = analytics.textbookPerformance[textbook];
                    tp.avgRating = Math.round((tp.totalRating / tp.sessions) * 10) / 10;
                    tp.avgScorePercent = tp.scoreCount > 0 ? Math.round(tp.totalScorePercent / tp.scoreCount) : null;
                    tp.sfMetPercent = tp.sfTotalCount > 0 ? Math.round((tp.sfMetCount / tp.sfTotalCount) * 100) : null;
                    tp.lessonCount = tp.lessons.length;
                    // Clean up intermediate values
                    delete tp.totalRating;
                    delete tp.totalScorePercent;
                    delete tp.scoreCount;
                    delete tp.sfMetCount;
                    delete tp.sfTotalCount;
                });

                res.json(analytics);
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get chart data (fast, no AI processing)
app.get('/api/chart-data', async (req, res) => {
    try {
        const { student, teacher, subject, startDate, endDate } = req.query;
        if (!student) {
            return res.status(400).json({ error: 'Student name required' });
        }

        const reports = [];

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                // Apply same filters as /api/reports
                let include = row['Student Name'] === student;

                if (include && teacher && row['Teacher Name'] !== teacher) include = false;
                if (include && subject && row['Subject'] !== subject) include = false;
                if (include && startDate && row['Date'] < startDate) include = false;
                if (include && endDate && row['Date'] > endDate) include = false;

                if (include) {
                    try {
                        row.Skills = row.Skills ? JSON.parse(row.Skills) : {};
                        row.Scores = row.Scores ? JSON.parse(row.Scores) : {};
                    } catch (e) {
                        row.Skills = {};
                        row.Scores = {};
                    }
                    reports.push(row);
                }
            })
            .on('end', () => {
                // Deduplicate reports (keep latest entry for each Student+Date+Subject)
                const dedupedReports = deduplicateReports(reports);

                if (dedupedReports.length === 0) {
                    return res.json({
                        averageRatings: {},
                        ratingsOverTime: [],
                        weaknessFrequency: [],
                        scoresOverTime: [],
                        scoresCategoryStats: {}
                    });
                }

                // Calculate chart data (same logic as AI analysis, but no OpenAI call)
                let ratingSum = { attention: 0, retention: 0, comprehension: 0, behavior: 0, handwriting: 0, conversation: 0 };
                const reportsByDate = {};
                const skillsWeaknesses = {};
                let scoresData = { overTime: [], categoryStats: {}, rawScoresByDate: {} };
                const skillFocusByDate = {};
                const skillFocusByTopic = {}; // Track skill focus success by topic name
                const subjectPerformance = {};

                dedupedReports.forEach(report => {
                    // Ratings
                    const ratings = {
                        date: report.Date,
                        attention: parseInt(report.Attention) || 0,
                        retention: parseInt(report.Retention) || 0,
                        comprehension: parseInt(report.Comprehension) || 0,
                        behavior: parseInt(report.Behavior) || 0,
                        handwriting: parseInt(report.Handwriting) || 0,
                        conversation: parseInt(report.Conversation) || 0
                    };

                    if (!reportsByDate[report.Date]) reportsByDate[report.Date] = [];
                    reportsByDate[report.Date].push(ratings);

                    Object.keys(ratingSum).forEach(key => ratingSum[key] += ratings[key]);

                    // Skills weaknesses (track dates for trend analysis) - split by keywords
                    if (report.Skills && typeof report.Skills === 'object') {
                        Object.entries(report.Skills).forEach(([skill, data]) => {
                            if (data.weaknesses && Array.isArray(data.weaknesses)) {
                                data.weaknesses.forEach(weaknessEntry => {
                                    // Split by comma and "and" to get individual keywords
                                    const keywords = weaknessEntry
                                        .split(/,|\band\b/i)
                                        .map(k => k.trim())
                                        .filter(k => k.length > 0);

                                    keywords.forEach(keyword => {
                                        // Normalize: capitalize first letter
                                        const displayName = keyword.charAt(0).toUpperCase() + keyword.slice(1).toLowerCase();
                                        const normalizedKey = keyword.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, ' ').trim();

                                        if (normalizedKey.length === 0) return;

                                        if (!skillsWeaknesses[normalizedKey]) {
                                            skillsWeaknesses[normalizedKey] = { count: 0, dates: [], displayName: displayName };
                                        }
                                        skillsWeaknesses[normalizedKey].count++;
                                        skillsWeaknesses[normalizedKey].dates.push(report.Date);
                                    });
                                });
                            }
                        });
                    }

                    // Score tracking
                    if (report.Scores && typeof report.Scores === 'object') {
                        const scoreLabels = { bookMaterials: 'Book/Materials', vocabulary: 'Vocabulary', classVideo: 'Class Video', homework: 'Homework', homeworkVocab: 'Homework Vocab', weeklyTest: 'Weekly Test' };

                        if (!scoresData.rawScoresByDate[report.Date]) scoresData.rawScoresByDate[report.Date] = {};

                        Object.entries(scoreLabels).forEach(([key, label]) => {
                            if (report.Scores[key]) {
                                const score = parseInt(report.Scores[key].score);
                                const total = parseInt(report.Scores[key].total);

                                if (!isNaN(score) && !isNaN(total) && total > 0) {
                                    const percentage = (score / total) * 100;

                                    if (!scoresData.rawScoresByDate[report.Date][key]) scoresData.rawScoresByDate[report.Date][key] = [];
                                    scoresData.rawScoresByDate[report.Date][key].push(percentage);

                                    if (!scoresData.categoryStats[key]) scoresData.categoryStats[key] = { label, count: 0, totalPercentage: 0 };
                                    scoresData.categoryStats[key].count++;
                                    scoresData.categoryStats[key].totalPercentage += percentage;
                                }
                            }
                        });
                    }

                    // Parse SF Met (handles both old YES/NO and new JSON format)
                    const sfMetParsed = parseSfMet(report['SF Met'], report['Skill Focus']);

                    // Track Skill Focus Met by date
                    if (!skillFocusByDate[report.Date]) {
                        skillFocusByDate[report.Date] = { met: 0, total: 0 };
                    }
                    skillFocusByDate[report.Date].total += sfMetParsed.totalCount || 1;
                    skillFocusByDate[report.Date].met += sfMetParsed.metCount;

                    // Track Skill Focus by individual keywords with per-skill met status
                    const skillFocusName = report['Skill Focus'];
                    if (skillFocusName && skillFocusName.trim() !== '') {
                        // Split by commas and "and" to get individual keywords
                        const keywords = skillFocusName
                            .split(/,|\band\b/i)
                            .map(k => k.trim())
                            .filter(k => k.length > 0);

                        keywords.forEach(keyword => {
                            // Clean display name: capitalize first letter
                            const displayName = keyword.charAt(0).toUpperCase() + keyword.slice(1).toLowerCase();

                            // Normalize key for grouping
                            const normalizedKey = keyword.toLowerCase()
                                .replace(/[^a-z0-9\s]/g, '')
                                .replace(/\s+/g, ' ')
                                .trim();

                            if (normalizedKey.length === 0) return;

                            if (!skillFocusByTopic[normalizedKey]) {
                                skillFocusByTopic[normalizedKey] = {
                                    met: 0,
                                    total: 0,
                                    subject: report.Subject,
                                    displayName: displayName,
                                    displayNameCounts: {}
                                };
                            }

                            // Track display name variations
                            if (!skillFocusByTopic[normalizedKey].displayNameCounts[displayName]) {
                                skillFocusByTopic[normalizedKey].displayNameCounts[displayName] = 0;
                            }
                            skillFocusByTopic[normalizedKey].displayNameCounts[displayName]++;

                            // Check per-skill met status (new format) or use overall (old format)
                            const isThisSkillMet = sfMetParsed.perSkill[keyword] !== undefined
                                ? sfMetParsed.perSkill[keyword]
                                : sfMetParsed.overallMet;

                            skillFocusByTopic[normalizedKey].total++;
                            if (isThisSkillMet) {
                                skillFocusByTopic[normalizedKey].met++;
                            }
                        });
                    }

                    // Track Subject Performance
                    if (report.Subject) {
                        if (!subjectPerformance[report.Subject]) {
                            subjectPerformance[report.Subject] = {
                                count: 0,
                                ratingSum: { attention: 0, retention: 0, comprehension: 0, behavior: 0, handwriting: 0, conversation: 0 }
                            };
                        }
                        subjectPerformance[report.Subject].count++;
                        subjectPerformance[report.Subject].ratingSum.attention += ratings.attention;
                        subjectPerformance[report.Subject].ratingSum.retention += ratings.retention;
                        subjectPerformance[report.Subject].ratingSum.comprehension += ratings.comprehension;
                        subjectPerformance[report.Subject].ratingSum.behavior += ratings.behavior;
                        subjectPerformance[report.Subject].ratingSum.handwriting += ratings.handwriting;
                        subjectPerformance[report.Subject].ratingSum.conversation += ratings.conversation;
                    }
                });

                // Calculate daily averages for ratingsOverTime
                const ratingsOverTime = [];
                Object.keys(reportsByDate).forEach(date => {
                    const dateReports = reportsByDate[date];
                    const dailyAverage = { date, attention: 0, retention: 0, comprehension: 0, behavior: 0, handwriting: 0, conversation: 0 };

                    dateReports.forEach(r => Object.keys(dailyAverage).forEach(k => { if (k !== 'date') dailyAverage[k] += r[k]; }));

                    const count = dateReports.length;
                    Object.keys(dailyAverage).forEach(k => { if (k !== 'date') dailyAverage[k] = parseFloat((dailyAverage[k] / count).toFixed(2)); });

                    ratingsOverTime.push(dailyAverage);
                });
                ratingsOverTime.sort((a, b) => new Date(a.date) - new Date(b.date));

                // Calculate daily averages for scores
                Object.keys(scoresData.rawScoresByDate).forEach(date => {
                    const dateScores = scoresData.rawScoresByDate[date];
                    const dailyScoreEntry = { date };

                    Object.keys(dateScores).forEach(category => {
                        const scores = dateScores[category];
                        const average = scores.reduce((sum, score) => sum + score, 0) / scores.length;
                        dailyScoreEntry[category] = parseFloat(average.toFixed(2));
                    });

                    scoresData.overTime.push(dailyScoreEntry);
                });
                scoresData.overTime.sort((a, b) => new Date(a.date) - new Date(b.date));

                // Calculate averages
                const averageRatings = {};
                Object.keys(ratingSum).forEach(key => averageRatings[key] = (ratingSum[key] / dedupedReports.length).toFixed(2));

                // Weakness frequency with trend analysis
                // Get all dates and find the midpoint to split early vs recent
                const allDates = dedupedReports.map(r => new Date(r.Date)).sort((a, b) => a - b);
                const midpointDate = allDates.length > 1 ? allDates[Math.floor(allDates.length / 2)] : allDates[0];

                const weaknessFrequency = Object.entries(skillsWeaknesses)
                    .map(([normalizedKey, data]) => {
                        // Count occurrences in early vs recent period
                        const earlyCount = data.dates.filter(d => new Date(d) <= midpointDate).length;
                        const recentCount = data.dates.filter(d => new Date(d) > midpointDate).length;

                        // Determine trend
                        let trend = 'stable';
                        if (recentCount > earlyCount) {
                            trend = 'worsening';
                        } else if (recentCount < earlyCount) {
                            trend = 'improving';
                        }

                        // Calculate priority score (higher = needs more attention)
                        // Worsening = high priority, Frequent + stable = medium, Improving = low
                        let priorityScore = data.count;
                        if (trend === 'worsening') {
                            priorityScore = data.count * 3 + recentCount * 2; // Boost worsening items
                        } else if (trend === 'improving') {
                            priorityScore = data.count * 0.5; // Lower priority for improving
                        }

                        // Calculate percentage change
                        const totalPeriods = earlyCount + recentCount;
                        const changePercent = totalPeriods > 0
                            ? Math.round(((recentCount - earlyCount) / Math.max(earlyCount, 1)) * 100)
                            : 0;

                        return {
                            weakness: data.displayName || normalizedKey,
                            count: data.count,
                            earlyCount,
                            recentCount,
                            trend,
                            priorityScore,
                            changePercent
                        };
                    })
                    .sort((a, b) => b.priorityScore - a.priorityScore) // Sort by priority
                    .slice(0, 15);

                // Skill Focus Met Over Time
                const skillFocusOverTime = Object.keys(skillFocusByDate)
                    .sort((a, b) => new Date(a) - new Date(b))
                    .map(date => ({
                        date,
                        percentage: (skillFocusByDate[date].met / skillFocusByDate[date].total * 100).toFixed(1),
                        met: skillFocusByDate[date].met,
                        total: skillFocusByDate[date].total
                    }));

                // Skill Focus Success Rate by Topic (sorted by success rate)
                // Use the most common display name variation for each topic
                const skillFocusBreakdown = Object.entries(skillFocusByTopic)
                    .map(([normalizedKey, data]) => {
                        // Find the most common display name variation
                        let bestDisplayName = data.displayName;
                        let maxCount = 0;
                        if (data.displayNameCounts) {
                            Object.entries(data.displayNameCounts).forEach(([name, count]) => {
                                if (count > maxCount) {
                                    maxCount = count;
                                    bestDisplayName = name;
                                }
                            });
                        }
                        return {
                            topic: bestDisplayName,  // Use most common display name
                            percentage: parseFloat((data.met / data.total * 100).toFixed(1)),
                            met: data.met,
                            total: data.total,
                            subject: data.subject
                        };
                    })
                    .sort((a, b) => b.percentage - a.percentage); // Sort by success rate descending

                // Subject Performance Comparison
                const subjectComparison = Object.keys(subjectPerformance).map(subject => {
                    const data = subjectPerformance[subject];
                    const avgRating = (
                        data.ratingSum.attention +
                        data.ratingSum.retention +
                        data.ratingSum.comprehension +
                        data.ratingSum.behavior +
                        data.ratingSum.handwriting +
                        data.ratingSum.conversation
                    ) / (data.count * 6);

                    return {
                        subject,
                        averageRating: parseFloat(avgRating.toFixed(2)),
                        reportCount: data.count
                    };
                }).sort((a, b) => b.averageRating - a.averageRating);

                res.json({
                    averageRatings,
                    ratingsOverTime,
                    weaknessFrequency,
                    scoresOverTime: scoresData.overTime,
                    scoresCategoryStats: scoresData.categoryStats,
                    skillFocusOverTime,
                    skillFocusBreakdown,
                    subjectComparison
                });
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Endpoint to get AI-powered analysis
app.get('/api/ai-analysis', async (req, res) => {
    try {
        const { student, teacher, subject, startDate, endDate } = req.query;
        if (!student) {
            return res.status(400).json({ error: 'Student name required' });
        }

        const reports = [];

        fs.createReadStream(CSV_PATH)
            .pipe(csv())
            .on('data', (row) => {
                // Apply same filters as /api/reports
                let include = row['Student Name'] === student;

                if (include && teacher && row['Teacher Name'] !== teacher) include = false;
                if (include && subject && row['Subject'] !== subject) include = false;
                if (include && startDate && row['Date'] < startDate) include = false;
                if (include && endDate && row['Date'] > endDate) include = false;

                if (include) {
                    try {
                        row.Skills = row.Skills ? JSON.parse(row.Skills) : {};
                        row.Scores = row.Scores ? JSON.parse(row.Scores) : {};
                    } catch (e) {
                        row.Skills = {};
                        row.Scores = {};
                    }
                    reports.push(row);
                }
            })
            .on('end', async () => {
                // Deduplicate reports (keep latest entry for each Student+Date+Subject)
                const dedupedReports = deduplicateReports(reports);

                if (dedupedReports.length === 0) {
                    return res.json({
                        strengths: [],
                        weaknessPatterns: [],
                        recommendations: [],
                        insights: 'No reports available for analysis.',
                        progressTrend: 'insufficient_data'
                    });
                }

                // Aggregate data for AI analysis
                // Get student gender from the first report (should be consistent)
                const studentGender = dedupedReports[0]['Student Gender'] || 'Unknown';
                const genderPronoun = studentGender === 'Male' ? 'he/him/his' :
                                      studentGender === 'Female' ? 'she/her/her' : 'they/them/their';

                const aggregatedData = {
                    studentName: student,
                    studentGender: studentGender,
                    genderPronoun: genderPronoun,
                    totalReports: dedupedReports.length,
                    dateRange: {
                        start: dedupedReports[dedupedReports.length - 1].Date,
                        end: dedupedReports[0].Date
                    },
                    averageRatings: {},
                    ratingsOverTime: [],
                    skillsWeaknesses: {},
                    subjects: {},
                    teachers: {},
                    skillFocusMet: { yes: 0, no: 0 },
                    narrativeSummaries: []
                };

                // Calculate metrics
                let ratingSum = {
                    attention: 0, retention: 0, comprehension: 0,
                    behavior: 0, handwriting: 0, conversation: 0
                };

                // Group reports by date for daily averages
                const reportsByDate = {};

                dedupedReports.forEach((report, index) => {
                    // Ratings
                    const ratings = {
                        date: report.Date,
                        attention: parseInt(report.Attention) || 0,
                        retention: parseInt(report.Retention) || 0,
                        comprehension: parseInt(report.Comprehension) || 0,
                        behavior: parseInt(report.Behavior) || 0,
                        handwriting: parseInt(report.Handwriting) || 0,
                        conversation: parseInt(report.Conversation) || 0
                    };

                    // Group by date for daily averages
                    if (!reportsByDate[report.Date]) {
                        reportsByDate[report.Date] = [];
                    }
                    reportsByDate[report.Date].push(ratings);

                    Object.keys(ratingSum).forEach(key => {
                        ratingSum[key] += ratings[key];
                    });

                    // Skills weaknesses
                    if (report.Skills && typeof report.Skills === 'object') {
                        Object.entries(report.Skills).forEach(([skill, data]) => {
                            if (data.weaknesses && Array.isArray(data.weaknesses)) {
                                data.weaknesses.forEach(weakness => {
                                    if (!aggregatedData.skillsWeaknesses[weakness]) {
                                        aggregatedData.skillsWeaknesses[weakness] = {
                                            count: 0,
                                            skills: new Set(),
                                            subjects: new Set()
                                        };
                                    }
                                    aggregatedData.skillsWeaknesses[weakness].count++;
                                    aggregatedData.skillsWeaknesses[weakness].skills.add(skill);
                                    aggregatedData.skillsWeaknesses[weakness].subjects.add(report.Subject);
                                });
                            }
                        });
                    }

                    // Subject tracking
                    aggregatedData.subjects[report.Subject] = (aggregatedData.subjects[report.Subject] || 0) + 1;

                    // Teacher tracking
                    aggregatedData.teachers[report['Teacher Name']] = (aggregatedData.teachers[report['Teacher Name']] || 0) + 1;

                    // Skill focus met (handles both old YES/NO and new JSON format)
                    const sfMetParsed = parseSfMet(report['SF Met'], report['Skill Focus']);
                    aggregatedData.skillFocusMet.yes += sfMetParsed.metCount;
                    aggregatedData.skillFocusMet.no += sfMetParsed.notMetCount;

                    // Narratives (last 5 for context)
                    if (index < 5 && report.Narrative) {
                        aggregatedData.narrativeSummaries.push(report.Narrative);
                    }

                    // Score tracking - collect all scores for later daily averaging
                    if (report.Scores && typeof report.Scores === 'object') {
                        if (!aggregatedData.scoresData) {
                            aggregatedData.scoresData = {
                                overTime: [],
                                categoryStats: {},
                                rawScoresByDate: {}
                            };
                        }

                        const scoreLabels = {
                            bookMaterials: 'Book/Materials',
                            vocabulary: 'Vocabulary',
                            classVideo: 'Class Video',
                            homework: 'Homework',
                            homeworkVocab: 'Homework Vocab',
                            weeklyTest: 'Weekly Test'
                        };

                        // Initialize date entry if needed
                        if (!aggregatedData.scoresData.rawScoresByDate[report.Date]) {
                            aggregatedData.scoresData.rawScoresByDate[report.Date] = {};
                        }

                        Object.entries(scoreLabels).forEach(([key, label]) => {
                            if (report.Scores[key]) {
                                const score = parseInt(report.Scores[key].score);
                                const total = parseInt(report.Scores[key].total);

                                if (!isNaN(score) && !isNaN(total) && total > 0) {
                                    const percentage = (score / total) * 100;

                                    // Store for daily averaging
                                    if (!aggregatedData.scoresData.rawScoresByDate[report.Date][key]) {
                                        aggregatedData.scoresData.rawScoresByDate[report.Date][key] = [];
                                    }
                                    aggregatedData.scoresData.rawScoresByDate[report.Date][key].push(percentage);

                                    // Track category stats
                                    if (!aggregatedData.scoresData.categoryStats[key]) {
                                        aggregatedData.scoresData.categoryStats[key] = {
                                            label: label,
                                            count: 0,
                                            totalPercentage: 0
                                        };
                                    }

                                    aggregatedData.scoresData.categoryStats[key].count++;
                                    aggregatedData.scoresData.categoryStats[key].totalPercentage += percentage;
                                }
                            }
                        });
                    }
                });

                // Calculate daily averages for ratingsOverTime
                Object.keys(reportsByDate).forEach(date => {
                    const dateReports = reportsByDate[date];
                    const dailyAverage = {
                        date: date,
                        attention: 0,
                        retention: 0,
                        comprehension: 0,
                        behavior: 0,
                        handwriting: 0,
                        conversation: 0
                    };

                    // Sum all ratings for this date
                    dateReports.forEach(report => {
                        dailyAverage.attention += report.attention;
                        dailyAverage.retention += report.retention;
                        dailyAverage.comprehension += report.comprehension;
                        dailyAverage.behavior += report.behavior;
                        dailyAverage.handwriting += report.handwriting;
                        dailyAverage.conversation += report.conversation;
                    });

                    // Calculate averages
                    const count = dateReports.length;
                    dailyAverage.attention = parseFloat((dailyAverage.attention / count).toFixed(2));
                    dailyAverage.retention = parseFloat((dailyAverage.retention / count).toFixed(2));
                    dailyAverage.comprehension = parseFloat((dailyAverage.comprehension / count).toFixed(2));
                    dailyAverage.behavior = parseFloat((dailyAverage.behavior / count).toFixed(2));
                    dailyAverage.handwriting = parseFloat((dailyAverage.handwriting / count).toFixed(2));
                    dailyAverage.conversation = parseFloat((dailyAverage.conversation / count).toFixed(2));

                    aggregatedData.ratingsOverTime.push(dailyAverage);
                });

                // Sort ratingsOverTime by date (oldest first, for chronological line chart)
                aggregatedData.ratingsOverTime.sort((a, b) => new Date(a.date) - new Date(b.date));

                // Calculate daily averages for scores
                if (aggregatedData.scoresData && aggregatedData.scoresData.rawScoresByDate) {
                    Object.keys(aggregatedData.scoresData.rawScoresByDate).forEach(date => {
                        const dateScores = aggregatedData.scoresData.rawScoresByDate[date];
                        const dailyScoreEntry = { date: date };

                        // Calculate average for each category on this date
                        Object.keys(dateScores).forEach(category => {
                            const scores = dateScores[category];
                            const average = scores.reduce((sum, score) => sum + score, 0) / scores.length;
                            dailyScoreEntry[category] = parseFloat(average.toFixed(2));
                        });

                        aggregatedData.scoresData.overTime.push(dailyScoreEntry);
                    });

                    // Sort scoresData.overTime by date (oldest first)
                    aggregatedData.scoresData.overTime.sort((a, b) => new Date(a.date) - new Date(b.date));

                    // Clean up temporary data
                    delete aggregatedData.scoresData.rawScoresByDate;
                }

                // Calculate averages
                Object.keys(ratingSum).forEach(key => {
                    aggregatedData.averageRatings[key] = (ratingSum[key] / dedupedReports.length).toFixed(2);
                });

                // Convert Sets to Arrays for JSON
                Object.keys(aggregatedData.skillsWeaknesses).forEach(weakness => {
                    aggregatedData.skillsWeaknesses[weakness].skills = Array.from(aggregatedData.skillsWeaknesses[weakness].skills);
                    aggregatedData.skillsWeaknesses[weakness].subjects = Array.from(aggregatedData.skillsWeaknesses[weakness].subjects);
                });

                // Sort weaknesses by frequency
                const sortedWeaknesses = Object.entries(aggregatedData.skillsWeaknesses)
                    .sort((a, b) => b[1].count - a[1].count)
                    .slice(0, 10); // Top 10 weaknesses

                // Build AI prompt
                const prompt = `You are an educational analyst. Analyze this student's performance data and provide actionable insights.

Student: ${aggregatedData.studentName}
Gender: ${aggregatedData.studentGender} (use pronouns: ${aggregatedData.genderPronoun})
Total Reports: ${aggregatedData.totalReports}
Date Range: ${aggregatedData.dateRange.start} to ${aggregatedData.dateRange.end}

IMPORTANT: When referring to this student, use the appropriate pronouns (${aggregatedData.genderPronoun}).

Average Ratings (out of 5):
- Attention: ${aggregatedData.averageRatings.attention}
- Retention: ${aggregatedData.averageRatings.retention}
- Comprehension: ${aggregatedData.averageRatings.comprehension}
- Behavior: ${aggregatedData.averageRatings.behavior}
- Handwriting: ${aggregatedData.averageRatings.handwriting}
- Conversation: ${aggregatedData.averageRatings.conversation}

Top Skill Weaknesses (frequency):
${sortedWeaknesses.map(([weakness, data]) => `- ${weakness}: ${data.count} times (in ${data.subjects.join(', ')})`).join('\n')}

Skill Focus Met: ${aggregatedData.skillFocusMet.yes} times YES, ${aggregatedData.skillFocusMet.no} times NO

Subjects Studied: ${Object.keys(aggregatedData.subjects).join(', ')}

${aggregatedData.scoresData ? `
Score Performance Summary:
${Object.entries(aggregatedData.scoresData.categoryStats).map(([key, stats]) => {
    const avgPercentage = (stats.totalPercentage / stats.count).toFixed(1);
    return `- ${stats.label}: ${avgPercentage}% average (appears in ${stats.count}/${aggregatedData.totalReports} reports)`;
}).join('\n')}
` : ''}

Recent Teacher Notes:
${aggregatedData.narrativeSummaries.slice(0, 3).join('\n\n')}

Please provide:
1. Top 3-5 STRENGTHS (what the student excels at)
2. Top 5-7 WEAKNESS PATTERNS (specific recurring issues with context)
3. 5-7 ACTIONABLE RECOMMENDATIONS (specific strategies for improvement)
4. PROGRESS INSIGHTS (overall trend, what's working, what needs attention)

Format your response as JSON:
{
  "strengths": ["strength 1", "strength 2", ...],
  "weaknessPatterns": [
    {"weakness": "name", "frequency": number, "context": "brief explanation"},
    ...
  ],
  "recommendations": ["recommendation 1", "recommendation 2", ...],
  "insights": "2-3 sentences about overall progress and key observations",
  "progressTrend": "improving|stable|declining"
}`;

                // Call OpenAI
                const response = await openai.chat.completions.create({
                    model: "gpt-4o-mini",
                    messages: [
                        {
                            role: "system",
                            content: "You are an expert educational analyst specializing in student performance analysis. Provide specific, actionable insights based on data."
                        },
                        {
                            role: "user",
                            content: prompt
                        }
                    ],
                    temperature: 0.7,
                    response_format: { type: "json_object" }
                });

                const aiAnalysis = JSON.parse(response.choices[0].message.content);

                // Add raw data for charts
                aiAnalysis.chartData = {
                    ratingsOverTime: aggregatedData.ratingsOverTime,
                    averageRatings: aggregatedData.averageRatings,
                    weaknessFrequency: sortedWeaknesses.map(([name, data]) => ({
                        name,
                        count: data.count
                    })),
                    subjectDistribution: aggregatedData.subjects,
                    skillFocusSuccess: {
                        met: aggregatedData.skillFocusMet.yes,
                        notMet: aggregatedData.skillFocusMet.no
                    },
                    scoresOverTime: aggregatedData.scoresData ? aggregatedData.scoresData.overTime : [],
                    scoresCategoryStats: aggregatedData.scoresData ? aggregatedData.scoresData.categoryStats : {}
                };

                // Add narratives at top level for word cloud
                aiAnalysis.narratives = dedupedReports.map(r => r.Narrative).filter(n => n && n.trim() !== '');

                // Add student gender for lesson prompt generation
                aiAnalysis.studentGender = aggregatedData.studentGender;
                aiAnalysis.genderPronoun = aggregatedData.genderPronoun;

                res.json(aiAnalysis);
            })
            .on('error', (error) => {
                console.error('Error reading CSV:', error);
                res.status(500).json({ error: 'Failed to read reports' });
            });
    } catch (error) {
        console.error('Error generating AI analysis:', error);
        res.status(500).json({ error: 'Failed to generate AI analysis' });
    }
});

// Helper function to determine performance level RELATIVE to student's actual enrolled grade
// This compares framework scores (0-100) to determine if student is above/at/below their actual grade level
function determinePerformanceLevel(frameworkScores, actualGrade) {
    // Calculate average framework score (0-100 scale)
    const avgScore = (
        (frameworkScores.balancing || 0) +
        (frameworkScores.nurturing || 0) +
        (frameworkScores.polishing || 0) +
        (frameworkScores.higherminds || 0)
    ) / 4;

    const actualGradeNum = parseInt(actualGrade) || 5; // Default to Grade 5 if not specified

    // Determine performance relative to actual grade
    // CONSERVATIVE thresholds - participation scores don't directly indicate grade-level academic performance
    // 90+ = Above grade level (truly exceptional)
    // 70-89 = At grade level (good participation does NOT mean above-grade academics)
    // 60-69 = Approaching grade level
    // <60 = Needs support
    let performanceLevel, performanceDescription, gradeComparison;

    if (avgScore >= 90) {
        // Only truly exceptional performance shows as above grade
        const performanceGrade = Math.min(actualGradeNum + 1, 12);
        performanceLevel = `Grade ${performanceGrade}`;
        performanceDescription = 'Above Grade Level';
        gradeComparison = 'above';
    } else if (avgScore >= 70) {
        // Good participation = At grade level (NOT above)
        performanceLevel = `Grade ${actualGradeNum}`;
        performanceDescription = 'At Grade Level';
        gradeComparison = 'at';
    } else if (avgScore >= 60) {
        // Developing - still at their grade, just needs support
        performanceLevel = `Grade ${actualGradeNum}`;
        performanceDescription = 'Approaching Grade Level';
        gradeComparison = 'approaching';
    } else {
        // Needs significant support - still at their enrolled grade level
        performanceLevel = `Grade ${actualGradeNum}`;
        performanceDescription = 'Needs Support';
        gradeComparison = 'below';
    }

    // Map to international frameworks based on ACTUAL grade, not inflated performance
    const ibMapping = {
        1: { level: 'PYP 1', sublabel: 'Primary Years Year 1' },
        2: { level: 'PYP 2', sublabel: 'Primary Years Year 2' },
        3: { level: 'PYP 3', sublabel: 'Primary Years Year 3' },
        4: { level: 'PYP 4', sublabel: 'Primary Years Year 4' },
        5: { level: 'PYP 5', sublabel: 'Primary Years Year 5' },
        6: { level: 'MYP 1', sublabel: 'Middle Years Year 1' },
        7: { level: 'MYP 2', sublabel: 'Middle Years Year 2' },
        8: { level: 'MYP 3', sublabel: 'Middle Years Year 3' },
        9: { level: 'MYP 4', sublabel: 'Middle Years Year 4' },
        10: { level: 'MYP 5', sublabel: 'Middle Years Year 5' },
        11: { level: 'DP 1', sublabel: 'Diploma Programme Year 1' },
        12: { level: 'DP 2', sublabel: 'Diploma Programme Year 2' }
    };

    const cambridgeMapping = {
        1: { level: 'Stage 1', sublabel: 'Primary' },
        2: { level: 'Stage 2', sublabel: 'Primary' },
        3: { level: 'Stage 3', sublabel: 'Primary' },
        4: { level: 'Stage 4', sublabel: 'Primary' },
        5: { level: 'Stage 5', sublabel: 'Primary' },
        6: { level: 'Stage 6', sublabel: 'Primary' },
        7: { level: 'Stage 7', sublabel: 'Lower Secondary' },
        8: { level: 'Stage 8', sublabel: 'Lower Secondary' },
        9: { level: 'Stage 9', sublabel: 'Lower Secondary' },
        10: { level: 'IGCSE 1', sublabel: 'Year 10' },
        11: { level: 'IGCSE 2', sublabel: 'Year 11' },
        12: { level: 'A-Level', sublabel: 'Year 12-13' }
    };

    // Use the ACTUAL grade for international benchmarks, not inflated performance
    const ib = ibMapping[actualGradeNum] || ibMapping[5];
    const cambridge = cambridgeMapping[actualGradeNum] || cambridgeMapping[5];
    const uscc = { level: `Grade ${actualGradeNum}`, sublabel: performanceDescription };

    return {
        ib,
        uscc,
        cambridge,
        performanceLevel,
        performanceDescription,
        gradeComparison,
        avgScore: avgScore.toFixed(1),
        actualGrade: actualGradeNum
    };
}

// Legacy function - kept for backward compatibility but now uses the new logic
function determineGradeLevel(overallPerformance, actualGrade = 5) {
    // Convert 0-5 scale to 0-100 for the new function
    const frameworkScores = {
        balancing: overallPerformance * 20,
        nurturing: overallPerformance * 20,
        polishing: overallPerformance * 20,
        higherminds: overallPerformance * 20
    };
    return determinePerformanceLevel(frameworkScores, actualGrade);
}

// Framework AI Analysis endpoint
app.get('/api/framework-ai-analysis', async (req, res) => {
    try {
        const { student, framework } = req.query;

        if (!student || !framework) {
            return res.status(400).json({ error: 'Student and framework data are required' });
        }

        // Parse framework data
        const frameworkData = JSON.parse(framework);

        // Get student gender for proper pronouns
        const studentGender = frameworkData.studentGender || 'Unknown';
        const genderPronoun = studentGender === 'Male' ? 'he/him/his' :
                              studentGender === 'Female' ? 'she/her/her' : 'they/them/their';

        // CRITICAL: Get the student's ACTUAL enrolled grade - this is the baseline
        const actualGrade = frameworkData.actualGrade || 5; // Default to Grade 5 if not specified

        // Calculate performance level RELATIVE to actual grade (not inflated)
        const performanceData = determinePerformanceLevel({
            balancing: frameworkData.balancing || 0,
            nurturing: frameworkData.nurturing || 0,
            polishing: frameworkData.polishing || 0,
            higherminds: frameworkData.higherminds || 0
        }, actualGrade);

        // Store the corrected grade level data
        frameworkData.gradeLevel = performanceData;
        frameworkData.performanceDescription = performanceData.performanceDescription;
        frameworkData.gradeComparison = performanceData.gradeComparison;

        // Extract academic performance data if provided by frontend
        const academicPerf = frameworkData.academicPerformance;

        // Build academic performance section for prompt
        let academicSection = '';
        if (academicPerf && academicPerf.components) {
            academicSection = `
=== ACADEMIC PERFORMANCE INDICATORS (PRIMARY ASSESSMENT) ===
Overall Academic Score: ${academicPerf.academicScore}/100
Performance Level: ${academicPerf.performanceDescription}

Component Breakdown:
1. Reading Level (30% weight): ${academicPerf.components.readingLevel.score}/100
   - Average Reading Level: ${academicPerf.components.readingLevel.avgLevel}
   - Expected for Grade ${actualGrade}: Grade ${actualGrade}
   - Data points: ${academicPerf.components.readingLevel.dataPoints} reports

2. Words Per Minute (25% weight): ${academicPerf.components.wpm.score}/100
   - Average WPM: ${academicPerf.components.wpm.avgWPM}
   - Expected for Grade ${actualGrade}: ${academicPerf.components.wpm.benchmark ? academicPerf.components.wpm.benchmark.expected : 'N/A'} WPM
   - Minimum for Grade ${actualGrade}: ${academicPerf.components.wpm.benchmark ? academicPerf.components.wpm.benchmark.min : 'N/A'} WPM
   - Data points: ${academicPerf.components.wpm.dataPoints} reports

3. Test Scores (25% weight): ${academicPerf.components.testScores.score}/100
   - Average Score: ${academicPerf.components.testScores.avgScore}
   - Data points: ${academicPerf.components.testScores.dataPoints} assessments

4. Skill Focus Met Rate (10% weight): ${academicPerf.components.skillFocusMet.score}/100
   - Met ${academicPerf.components.skillFocusMet.met} out of ${academicPerf.components.skillFocusMet.total} sessions

5. Classroom Participation (10% weight): ${academicPerf.components.participation.score}/100
   - This is from the framework scores (Attention, Retention, etc.)
`;
        }

        const prompt = `You are an educational development specialist analyzing a student's performance data.

STUDENT: ${student}
GENDER: ${studentGender} (use pronouns: ${genderPronoun})
ENROLLED GRADE: Grade ${actualGrade}
${academicPerf ? `ACADEMIC PERFORMANCE: ${academicPerf.performanceDescription} (Score: ${academicPerf.academicScore}/100)` : `PERFORMANCE STATUS: ${performanceData.performanceDescription}`}

IMPORTANT: When referring to this student, use the appropriate pronouns (${genderPronoun}).
${academicSection}

=== CLASSROOM PARTICIPATION SCORES (SECONDARY - 10% of overall) ===
- Balancing (Weaving): ${frameworkData.balancing}/100 - Input-Output balance (Attention + Retention)
- Nurturing: ${frameworkData.nurturing}/100 - Logical explanation ability (Comprehension + Conversation)
- Polishing: ${frameworkData.polishing}/100 - Quality & creativity (Handwriting + Test Scores + Skill Focus Met)
- Higher-minds: ${frameworkData.higherminds}/100 - Metacognition (Behavior & self-regulation)

=== INTERPRETATION GUIDE ===
Academic Score Thresholds:
- 85+ = Above grade level (reading/WPM/tests all exceed Grade ${actualGrade} expectations)
- 70-84 = At grade level (meeting Grade ${actualGrade} expectations)
- 55-69 = Approaching grade level (some gaps in Grade ${actualGrade} skills)
- Below 55 = Below grade level (significant gaps requiring intervention)

STUDENT'S CURRENT STATUS: ${academicPerf ? academicPerf.performanceDescription : performanceData.performanceDescription}
${academicPerf ? `Based on ACTUAL academic indicators (reading level, WPM, test scores), this student is performing ${academicPerf.gradeComparison === 'above' ? 'ABOVE' : academicPerf.gradeComparison === 'at' ? 'AT' : academicPerf.gradeComparison === 'approaching' ? 'SLIGHTLY BELOW' : 'BELOW'} Grade ${actualGrade} expectations.` : ''}

CRITICAL INSTRUCTIONS:
- Use the ACADEMIC PERFORMANCE INDICATORS as your primary assessment (if available)
- Classroom participation scores are SECONDARY - good attention doesn't mean above-grade academics
- ALL analysis must be relative to Grade ${actualGrade} expectations
- DO NOT inflate or exaggerate performance levels
- If Reading Level is below Grade ${actualGrade}, the student is NOT "above grade level" regardless of participation
- If WPM is below the expected benchmark, acknowledge this gap
- Be realistic and honest about where the student stands
- Recommendations should target the WEAKEST academic components first

Please provide a comprehensive analysis with FOUR sections:

1. FRAMEWORK INTERPRETATION:
   - Explain what these scores reveal about the student's developmental profile FOR A GRADE ${actualGrade} STUDENT
   - Current status: ${performanceData.performanceDescription} - explain what this means practically
   - How do the four dimensions interact? What does the pattern suggest about their learning style?
   - Be honest: if scores are in the 60s, they need support - don't sugarcoat it

2. DEVELOPMENTAL STRENGTHS:
   - Identify which framework dimensions show relative strength (highest scores)
   - Explain what these strengths enable the student to do AT THEIR GRADE ${actualGrade} LEVEL
   - Be realistic - a score of 70 is "meeting expectations", not "exceptional"
   - Only describe as "above grade level" if scores are 80+

3. GROWTH OPPORTUNITIES:
   - Identify which dimensions need the most development (lowest scores)
   - Be specific about what skills need work for a Grade ${actualGrade} student
   - How might these gaps affect their academic progress?
   - Prioritize: what's most critical to address first?

4. TARGETED INTERVENTIONS:
   - Provide 3-4 specific, actionable recommendations appropriate for Grade ${actualGrade}
   - Each recommendation should:
     * Target a specific framework dimension with the lowest score
     * Include concrete strategies a Grade ${actualGrade} student can actually do
     * Be achievable within a few weeks, not months
     * Focus on foundational skills appropriate for their grade level
   - DO NOT suggest advanced techniques for a student who needs foundational support

Write in a professional, educator-to-educator tone. Be honest and realistic - avoid inflating the student's performance. A Grade ${actualGrade} student with scores in the 60s needs support, not praise.

Format your response as JSON with this structure:
{
  "interpretation": "2-3 paragraphs...",
  "strengths": "2-3 paragraphs...",
  "growth": "2-3 paragraphs...",
  "interventions": "2-3 paragraphs with 3-4 numbered interventions..."
}`;

        // Call OpenAI API
        const completion = await openai.chat.completions.create({
            model: 'gpt-4o-mini',
            messages: [
                { role: 'system', content: `You are an educational development specialist for the ICAN STELLAR program. CRITICAL: Always base your analysis on the student's ACTUAL enrolled grade level. Do NOT inflate performance assessments. A score of 65-75 means "developing/approaching grade level" - NOT "excelling". Be honest and realistic in your assessments. Recommendations must be grade-appropriate and achievable.` },
                { role: 'user', content: prompt }
            ],
            response_format: { type: 'json_object' },
            temperature: 0.7
        });

        const analysis = JSON.parse(completion.choices[0].message.content);

        res.json({
            student,
            framework: frameworkData,
            performanceLevel: performanceData.performanceLevel,
            performanceDescription: performanceData.performanceDescription,
            gradeComparison: performanceData.gradeComparison,
            actualGrade: actualGrade,
            avgScore: performanceData.avgScore,
            analysis
        });

    } catch (error) {
        console.error('Error generating framework AI analysis:', error);
        res.status(500).json({ error: 'Failed to generate framework AI analysis' });
    }
});

app.listen(port, '0.0.0.0', () => {
    console.log(`Student Report Viewer running at http://localhost:${port}`);
    console.log(`Reading reports from: ${CSV_PATH}`);
});
